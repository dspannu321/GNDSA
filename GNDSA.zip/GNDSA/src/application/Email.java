package application;

import java.sql.Date;

public class Email {
 private int senderID;
 private Date sendDate;
 private String subject;
 private String message;
 
public Email(int senderID, Date sendDate, String subject, String message) {
	this.senderID = senderID;
	this.sendDate = sendDate;
	this.subject = subject;
	this.message = message;
}

public int getSenderID() {
	return senderID;
}

public void setSenderID(int senderID) {
	this.senderID = senderID;
}

public Date getSendDate() {
	return sendDate;
}

public void setSendDate(Date sendDate) {
	this.sendDate = sendDate;
}

public String getSubject() {
	return subject;
}

public void setSubject(String subject) {
	this.subject = subject;
}

public String getMessage() {
	return message;
}

public void setMessage(String message) {
	this.message = message;
}


 
 
}
