package application;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.stage.Stage;

public class AssignMissionToTeam implements Initializable {
@FXML private ComboBox <Integer> Mission;
@FXML private ComboBox <Integer> Team;
showAlert alert=new showAlert();
ArrayList <Integer> missions= new ArrayList<Integer>();
ArrayList <Integer> teams   = new ArrayList<Integer>();
static Stage window;
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		try {
			load();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	 Mission.getItems().addAll(missions);
	 Team.getItems().addAll(teams);
	}
	public void assignButton(ActionEvent ev) throws IOException {
		try{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/gndsa","root","");
		    Statement stmt=con.createStatement();
		    String sql="UPDATE aerospaceteam SET MissionID="+Mission.getValue()+" WHERE TeamID="+Team.getValue(); 
		    int rs=stmt.executeUpdate(sql);
		    String sqlMisison="UPDATE mission SET MissionStatus='Assigned' WHERE missionID="+Mission.getValue();
		    int rsmis=stmt.executeUpdate(sqlMisison);
		    SendEmail.sendBroadcastMail(70001, Team.getValue(), "2018-11-26","Automatic mail. Mission Assigned","Hello Members of team "+Team.getValue()+". You have been assigned to mission. Your misison ID is "+Mission.getValue()+". Please Log into your employee portal and go to View mission Status to view Mission Details. Good Luck");
			if(rs==1) {
				alert.display("Mission Has Been Assigned To Team , Good luck!");
				Parent add = FXMLLoader.load(getClass().getResource("AerospaceManagerDashboard.fxml"));
		         Scene addMission=new Scene(add);
		         Stage window=(Stage)((Node)ev.getSource()).getScene().getWindow();
		         window.setScene(addMission);
			}
		}
		catch(Exception e) {
			System.out.println(e);
			alert.display("Failed Assigning Mission to Team");
		}
	}
	public void load() throws IOException {
		try {
		teams.clear();
		missions.clear();
		int count=0;
		Class.forName("com.mysql.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/gndsa","root","");
	    Statement stmt=con.createStatement();
	    String sqlgetTeams="Select TeamID From `AerospaceTeam` Where MissionID='0'";
	    ResultSet rs=stmt.executeQuery(sqlgetTeams);
	    while(rs.next()) {
	     teams.add(rs.getInt("TeamID"));
	   }
	  String sqlgetMissions="Select MissionID From `mission` Where MissionStatus='0'";
	  ResultSet rs1=stmt.executeQuery(sqlgetMissions);
	  while(rs1.next()) {
	     missions.add(rs1.getInt("MissionID"));
	     //System.out.println(rs.getInt("MissionID"));
	  }
	  }
		catch(Exception e) {
			System.out.println(e);
			alert.display("Failed loading data from Database");
		}
	}
	public Stage getWindow() {
		return window;
	}
	public static void setWindow(Stage win) {
		window = win;
	}
	public void backButton(ActionEvent e) throws IOException {
		Parent add = FXMLLoader.load(getClass().getResource("AerospaceManagerDashboard.fxml"));
        Scene hrDashboard=new Scene(add);
        Stage  hrDasboardView=(Stage)((Node)e.getSource()).getScene().getWindow();
        hrDasboardView.setScene(hrDashboard);
		
	}
	

}
