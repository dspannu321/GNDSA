package application;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class EditEmployee implements Initializable {
	 @FXML TextField fName;
	 @FXML TextField lName;
	 @FXML ComboBox<String> Dept;
	 @FXML DatePicker DOB;
	 @FXML ComboBox<String> Position;
	 @FXML TextField passWord;
	 @FXML Label empID;
	 @FXML Label initial;
	 Stage window;
	 String Fname, Lname, dept, Pos, pass,dob;
	 showAlert alert=new showAlert();
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		Dept.getItems().addAll("Engineering","HR","Aerospace","Research");
		Position.getItems().addAll("Manager","Lead","Engineer");
		
	}

	 public void setDataVal(String ID,String Fname, String Lname, String Dept, String Pos, String pass,Date dob) {
		 this.Fname=Fname;
		 this.Lname=Lname;
		 dept=Dept;
		 this.Pos=Pos;
		 this.pass=pass;
		 this.dob=dob.toString();
		 fName.setText(Fname);
		 lName.setText(Lname);
		 passWord.setText(pass);
		 empID.setText(ID);
		 this.Dept.setValue(Dept);
		 Position.setValue(Pos);
		 DOB.setValue(dob.toLocalDate());
		 String first=fName.getText().toString().substring(0,1).toUpperCase();
		 initial.setText(lName.getText().toString()+","+first);	
	    }
	 public void savebutton() throws IOException {
		 changeF_Name(Fname,fName.getText());
		 changeL_Name(Lname,lName.getText());
		 changeDept(dept,Dept.getValue().toString());
		 changeDOB(dob,DOB.getValue().toString());
		 changePassword(pass,passWord.getText());
		 changePosition(Pos,Position.getValue().toString());
		 
	 }
	 public void changeF_Name(String oldFname,String newFName) throws NumberFormatException, IOException{
		 if (!newFName.equals(oldFname)) {
				if(alert.printConfirm("Confirm First Name Change to "+newFName).equals("YES"))
				{
					Fname=newFName;
					updateEmployeeFNameSQL(newFName,new Integer (empID.getText()),null);
				}
			}
		 
	 }
     public void changeL_Name(String oldLname,String newLName) throws NumberFormatException, IOException{
    	 if (!newLName.equals(oldLname)) {
				if(alert.printConfirm("Confirm Last Name Change to "+newLName).equals("YES"))
				{
					Lname=newLName;
					updateEmployeeLNameSQL(newLName,new Integer (empID.getText()),null);
				}
			} 
		
	 }
     public void changeDept(String oldDept, String newDept) throws NumberFormatException, IOException {
    	 if (!newDept.equals(oldDept)) {
				if(alert.printConfirm("Confirm Department Change to "+newDept).equals("YES"))
				{
					dept=newDept;
					updateEmployeeDeptSQL(newDept,new Integer (empID.getText()),null);
				}
			} 
     }
     public void changeDOB(String oldDOB, String newDOB) throws NumberFormatException, IOException {
    	 if (!newDOB.equals(oldDOB)) {
				if(alert.printConfirm("Confirm DOB Change to "+newDOB).equals("YES"))
				{
					dob=newDOB;
					updateEmployeeDOBSQL(newDOB,new Integer (empID.getText()),null);
				}
			} 
     }
     public void changePassword(String oldPassword, String newPassword) throws NumberFormatException, IOException {
    	 if (!newPassword.equals(oldPassword)) {
				if(alert.printConfirm("Confirm Password Change to "+newPassword).equals("YES"))
				{
					pass=newPassword;
					updateEmployeePassSQL(newPassword,new Integer (empID.getText()),null);
				}
			}  
     }
	 public void changePosition(String oldPosition, String newPosition) throws NumberFormatException, IOException {
		 if (!newPosition.equals(oldPosition)) {
				if(alert.printConfirm("Confirm Position Change to "+newPosition).equals("YES"))
				{
					Pos=newPosition;
					updateEmployeePosSQL(newPosition,new Integer (empID.getText()),null);
				}
			} 
	 }
	 public void updateEmployeeFNameSQL(String FName,int ID,ActionEvent e) throws IOException {
		 try{
			 
				Class.forName("com.mysql.jdbc.Driver");
				Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/gndsa","root","");
			    Statement stmt=con.createStatement();
			    String updateFName="UPDATE employee SET Employee_FName='"+FName+"' WHERE Employee_ID="+ID;
			    int rs=stmt.executeUpdate(updateFName);
			    System.out.println(rs);
	             if(rs==1) {

	           	  alert.display("First Name Changed to "+FName+" For Employee "+ID);  

	             }
		 }
		 catch (Exception ev){
				alert.display("Failed updating Information"); 
			}
	 }
	 public void updateEmployeeLNameSQL(String LName,int ID,ActionEvent e) throws IOException {
		 try{
			 
				Class.forName("com.mysql.jdbc.Driver");
				Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/gndsa","root","");
			    Statement stmt=con.createStatement();
			    String updateLName="UPDATE employee SET Employee_LName='"+LName+"' WHERE Employee_ID="+ID;
			    int rs=stmt.executeUpdate(updateLName);
			    System.out.println(rs);
	             if(rs==1) {

	           	  alert.display("Last Name Changed to "+LName+" For Employee "+ID);  

	             }
		 }
		 catch (Exception ev){
				alert.display("Failed updating Information"); 
			}
	 }
	 public void updateEmployeeDeptSQL(String Dept,int ID,ActionEvent e) throws IOException {
		 try{
			 
				Class.forName("com.mysql.jdbc.Driver");
				Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/gndsa","root","");
			    Statement stmt=con.createStatement();
			    String updateDept="UPDATE employee SET Department='"+Dept+"' WHERE Employee_ID='"+ID+"' AND isAssigned='0'";
			    int rs=stmt.executeUpdate(updateDept);
			    System.out.println(rs);
	             if(rs==1) {

	           	  alert.display("Department Changed to "+Dept+" For Employee "+ID);  

	             }
		 }
		 catch (Exception ev){
				alert.display("Failed updating Information"); 
			}
	 }
	 public void updateEmployeeDOBSQL(String DOB,int ID,ActionEvent e) throws IOException {
		 try{
			 
				Class.forName("com.mysql.jdbc.Driver");
				Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/gndsa","root","");
			    Statement stmt=con.createStatement();
			    String updateDOB="UPDATE employee SET Dob='"+DOB+"' WHERE Employee_ID="+ID;
			    int rs=stmt.executeUpdate(updateDOB);
			    System.out.println(rs);
	             if(rs==1) {

	           	  alert.display("DOB Changed to "+this.DOB.getValue()+" For Employee "+ID);  

	             }
		 }
		 catch (Exception ev){
				alert.display("Failed updating Information"); 
			}
	 }
	 public void updateEmployeePassSQL(String Pass,int ID,ActionEvent e) throws IOException {
		 try{
			 
				Class.forName("com.mysql.jdbc.Driver");
				Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/gndsa","root","");
			    Statement stmt=con.createStatement();
			    String updatePass="UPDATE employee SET passWord='"+Pass+"' WHERE Employee_ID="+ID;
			    int rs=stmt.executeUpdate(updatePass);
			    System.out.println(rs);
	             if(rs==1) {

	           	  alert.display("Password Changed to "+Pass+" For Employee "+ID);  

	             }
		 }
		 catch (Exception ev){
				alert.display("Failed updating Information"); 
			}
	 }
	 public void updateEmployeePosSQL(String Pos,int ID,ActionEvent e) throws IOException {
		 try{
			 
				Class.forName("com.mysql.jdbc.Driver");
				Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/gndsa","root","");
			    Statement stmt=con.createStatement();
			    String updatePos="UPDATE employee SET Position='"+Pos+"' WHERE Employee_ID='"+ID+"' AND isAssigned='0'";
			    int rs=stmt.executeUpdate(updatePos);
			    System.out.println(rs);
	             if(rs==1) {

	           	  alert.display("Position Changed to "+Pos+" For Employee "+ID);  

	             }
		 }
		 catch (Exception ev){
				alert.display("Failed updating Information"); 
			}
	 }

	public Stage getWindow() {
		return window;
	}

	public void setWindow(Stage window) {
		this.window = window;
	}
	public void closeButton() {
		window.close();
	}
	
}
