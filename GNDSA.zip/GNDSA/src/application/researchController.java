package application;

import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

public class researchController implements Initializable {

	@FXML private TableView <Research> ResearchTable;
	@FXML private TableColumn<Research,Integer> ResearchCode;
	@FXML private TableColumn<Research,String> ResearchName;
	@FXML private TableColumn<Research,String> ResearchField;
	@FXML private TableColumn<Research,String> ResearchTopic;
	@FXML private TableColumn <Research,Integer> EmployeeID;
	
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		ResearchCode.setCellValueFactory(new PropertyValueFactory<Research,Integer>("ResearchCode"));
		ResearchName.setCellValueFactory(new PropertyValueFactory<Research,String>("ResearchName"));
		ResearchField.setCellValueFactory(new PropertyValueFactory<Research,String>("ResearchField"));
		ResearchTopic.setCellValueFactory(new PropertyValueFactory<Research,String>("ResearchTopic"));
		EmployeeID.setCellValueFactory(new PropertyValueFactory<Research,Integer>("EmployeeID"));
		ResearchTable.setItems(getResearch());
		
	}

	public ObservableList<Research> getResearch(){
		ObservableList<Research> Research=FXCollections.observableArrayList();
		try{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/gndsa","root","");
		    Statement stmt=con.createStatement();
		    String sql="Select * From `Research`";
		    ResultSet rs=stmt.executeQuery(sql);
		    while(rs.next()) {
		    int ID =rs.getInt("Research_Code");
		    String resName=rs.getString("Research_Name");
		    String resFie=rs.getString("Research_Field");
		    String resTop=rs.getString("Research_Topic");
		    int empID=rs.getInt("Employee_ID");
		    Research.add(new Research (ID,resName,resFie,resTop,empID));
		    }
		}
		catch (Exception e){
			System.out.println(e);;
		}
		
		return Research;
		
	}

	
	


}
