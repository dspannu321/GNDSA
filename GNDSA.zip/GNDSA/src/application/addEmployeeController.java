package application;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.util.ResourceBundle;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class addEmployeeController implements Initializable {
	@FXML TextField FirstName;
	@FXML TextField Lastname;
	@FXML ComboBox<String> Department;
	@FXML TextField Password;
	@FXML DatePicker DOB;
	@FXML ComboBox<String> Position;
	Stage thisWindow;
	showAlert alert=new showAlert();
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		Department.getItems().addAll("Engineering","HR","Aerospace","Research");
		Position.getItems().addAll("Manager","Lead","Engineer");
		
	}
    public void addButton() throws IOException {
    	try{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/gndsa","root","");
		    Statement stmt=con.createStatement();
		    String sql="INSERT INTO `employee` (`Employee_ID`, `passWord`, `Employee_FName`, `Employee_LName`, `Department`, `Dob`,`Position`, `isAssigned`) VALUES (NULL, '"+
		    Password.getText()+"', '"+FirstName.getText()+"', '"+Lastname.getText()+"', '"+Department.getValue().toString()+"','"+DOB.getValue()+"','"+Position.getValue().toString()+"','0')";
		    
		    @SuppressWarnings("unused")
			int rs=stmt.executeUpdate(sql);
		         alert.display("Adding Successful");
		         thisWindow.close();
		}
		catch (Exception ev){
			System.out.println(ev);
			alert.display("Fields cannot be left blank");
		}	
    }
    public void clearButton() {
    	FirstName.clear();
    	Lastname.clear();
    	Password.clear();
    }
	public Stage getThisWindow() {
		return thisWindow;
	}
	public void setThisWindow(Stage thisWindow) {
		this.thisWindow = thisWindow;
	}
    
}
