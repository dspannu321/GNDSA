package application;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class SearchMailController implements Initializable {
@FXML private TableView   <Email>         mailTable;
@FXML private TableColumn <Email,Integer> Sender;
@FXML private TableColumn <Email,Date>    date;
@FXML private TableColumn <Email,String>  Subject;
ObservableList<Email> mail=FXCollections.observableArrayList();
showAlert alert=new showAlert();
public int userLogged;
Stage window;
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		Sender.setCellValueFactory(new PropertyValueFactory<Email,Integer>("senderID"));
		date.setCellValueFactory(new PropertyValueFactory<Email,Date>("sendDate"));
		Subject.setCellValueFactory(new PropertyValueFactory<Email,String>("subject"));
		mailTable.setItems(getMail());
	}
	
	public int getUserLogged() {
		return userLogged;
	}

	public void setUserLogged(int userLogged) {
		this.userLogged = userLogged;
	}

    public ObservableList <Email> getMail(){
		return mail;
     }
		
	public void openButtonClick() throws IOException {
		try {
			FXMLLoader loader=new FXMLLoader();
			loader.setLocation(getClass().getResource("MailView.fxml"));
			Parent table=loader.load();
			Scene detailedScene=new Scene(table); 
			mailViewController controller=loader.getController();
			controller.setData(mailTable.getSelectionModel().getSelectedItem());
			Stage stage=new Stage();
			controller.setWindow(stage);
			stage.initModality(Modality.APPLICATION_MODAL);
			Image icon = new Image(getClass().getResourceAsStream("GNDSA.png"));
		    stage.getIcons().add(icon);
		    stage.setTitle(mailTable.getSelectionModel().getSelectedItem().toString());
			stage.setScene(detailedScene);
			stage.showAndWait();
			stage.close();
		}
		catch(Exception ev)
		{
			alert.display("No Data Selected");
		}
	}
	public void backButton(ActionEvent e) throws IOException {
		System.out.println("SearchMailController BackButton Clicked");
	window.close();
	}
	
	
	public void load( int id,String searchid) throws IOException {
	System.out.println("load metdod "+id+"  "+searchid);
		int count=0;
		try{
			mail.clear();
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/gndsa","root","");
		    Statement stmt=con.createStatement();
		    String sql="Select * From T"+id+" WHERE SID="+searchid;
		    ResultSet rs=stmt.executeQuery(sql);
		  while(rs.next()) {
		    int SID =rs.getInt("SID");
		    Date sDate=rs.getDate("sendDate");
		    String Sub=rs.getString("Subject");
		    String mess=rs.getString("message");
		    mail.add(new Email (SID,sDate,Sub,mess));
		    count ++;
		    }
		}
		catch (Exception e){
			System.out.println(e);
			System.out.println("SearchMailController load Clicked");
			alert.display("You Havent Been Assigned to Mission");
		}
	}

	public void setWindow(Stage stage) {
		window=stage;
		
	}

}

