package application;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class EditMission  implements Initializable {
	@FXML TextField missionName;
	@FXML Label mID;
	@FXML ComboBox<String> missionCategory;
	@FXML ComboBox<String> missionType;
	@FXML ComboBox<String> missionSubCat;
	@FXML ComboBox<String> missionPlanet;
	String mName,mCat,mSubCat,mType,mPlanet;
	
	showAlert alert=new showAlert();
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		missionCategory.getItems().addAll("Planetary","Space","Deep-Space","Lunar");
		missionType.getItems().addAll("NA","Impact", "Rover","Lander","Orbiter","Fly-By","Gravity Assist");
		missionSubCat.getItems().addAll("NA","Space telescope", "Communication Sattelite","Space Lab");
		missionPlanet.getItems().addAll("NA","Mercury","Venus","Mars","Jupiter");	
		
	}
	 public void setDataVal(String ID,String name, String Cat, String subCat, String type, String planet) {
		    mName=name;
		    mCat=Cat;
		    mSubCat=subCat;
		    mType=type;
		    mPlanet=planet;
	    	missionName.setText(mName);
			missionCategory.setValue(mCat);
			missionType.setValue(mType);
			missionSubCat.setValue(mSubCat);
			missionPlanet.setValue(mPlanet);
			mID.setText(ID);
	    	
	    	
	    }
public void saveButton() throws IOException {
	
changeName(mName,missionName.getText());
changeCat(mCat,missionCategory.getValue().toString());
changeType(mType,missionType.getValue().toString());
changeSubCat(mSubCat,missionSubCat.getValue().toString());
changePlanet(mPlanet,missionPlanet.getValue().toString());

	
}
public void clearButton() {
	
	
}
public void changeName(String oldName, String newName) throws IOException {
	if (!newName.equals(oldName)) {
		if(alert.printConfirm("Confirm Name Change to "+newName).equals("YES"))
		{
			mName=newName;
			updateMissionNameSQL(newName,new Integer (mID.getText()),null);
			System.out.println("Name Changed to "+newName);
		}
	}
}
public void changeCat(String oldCat,String newCat) throws IOException {
	if (!newCat.equals(oldCat)) {
		if(alert.printConfirm("Confirm Category Change to "+newCat).equals("YES"))
		{
			mCat=newCat;
			updateMissionCategorySQL(newCat,new Integer (mID.getText()),null);
			System.out.println("Cat Changed to "+newCat);
		}
	}
}
public void changeSubCat(String oldSubCat, String newSubCat) throws IOException {
	if (!newSubCat.equals(oldSubCat)) {
		if(alert.printConfirm("Confirm SubCat Change to "+newSubCat).equals("YES"))
		{	
			mSubCat=newSubCat;
			updateMissionSubCatSQL(newSubCat,new Integer (mID.getText()),null);
			System.out.println("SubCat Changed to "+newSubCat);
		}
	}
}
public void changeType(String oldType, String newType) throws IOException {
	if (!newType.equals(oldType)) {
		if(alert.printConfirm("Confirm Type Change to "+newType).equals("YES"))
		{	
			mType=newType;
			updateMissionTypeSQL(newType,new Integer (mID.getText()),null);
			System.out.println("Type Changed to "+newType);
		}
	}
}
public void changePlanet(String oldPlanet, String newPlanet) throws IOException {
	if (!newPlanet.equals(oldPlanet)) {
		if(alert.printConfirm("Confirm Planet Change to "+newPlanet).equals("YES"))
		{
			mPlanet=newPlanet;
			updateMissionPlanetSQL(newPlanet,new Integer (mID.getText()),null);
			System.out.println("Planet Changed to "+newPlanet);
		}
	}
}
public void updateMissionNameSQL(String Name,int ID,ActionEvent e) throws IOException {
	
	 try{
		 
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/gndsa","root","");
		    Statement stmt=con.createStatement();
		    String sqlVer="SELECT * FROM `mission` WHERE `MissionName` = '"+Name+"'";
		    ResultSet result=stmt.executeQuery(sqlVer);
		    if(result.next()) {
		    	alert.display("Mission \"" + Name+ "\" Already Exists");	
		    	missionTableViewCotroller c=new missionTableViewCotroller();
		    	c.load();
		    }
		    else {
		    String sql="UPDATE `mission` SET `MissionName` = '"+Name+"' WHERE `mission`.`MissionID` = "+ID+";";
		    int rs=stmt.executeUpdate(sql);
		    System.out.println(rs);
             if(rs==1) {

           	  alert.display("Name Changed to "+Name+" For Misison "+ID);  

             }
		}
	 }
		catch (Exception ev){
			alert.display("Failed updating System"); 
		}
	 
}
public void updateMissionCategorySQL(String Cat,int ID,ActionEvent e) throws IOException {
	 try{
		 
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/gndsa","root","");
		    Statement stmt=con.createStatement();
		    String sql="UPDATE `mission` SET `MissionCat` = '"+Cat+"' WHERE `mission`.`MissionID` = "+ID+";";
		    int rs=stmt.executeUpdate(sql);
		    System.out.println(rs);
          if(rs==1) {

       	   alert.display("Category Changed to "+Cat+" For Misison "+ID);  
		         
          }
		}
		catch (Exception ev){
			alert.display("Failed updating System"); 
		}
}

public void updateMissionSubCatSQL(String SubCat,int ID,ActionEvent e) throws IOException {
	 try{
		 
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/gndsa","root","");
		    Statement stmt=con.createStatement();
		    String sql="UPDATE `mission` SET `MissionSubCat` = '"+SubCat+"' WHERE `mission`.`MissionID` = "+ID+";";
		    int rs=stmt.executeUpdate(sql);
		    System.out.println(rs);
         if(rs==1) {

       	  alert.display("Sub-Category Changed to "+SubCat+" For Misison "+ID); 
		         
         }
		}
		catch (Exception ev){
			alert.display("Failed updating System"); 
		}
}
public void updateMissionTypeSQL(String Type,int ID,ActionEvent e) throws IOException {
	 try{
		 
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/gndsa","root","");
		    Statement stmt=con.createStatement();
		    String sql="UPDATE `mission` SET `MissionType` = '"+Type+"' WHERE `mission`.`MissionID` = "+ID+";";
		    int rs=stmt.executeUpdate(sql);
		    System.out.println(rs);
         if(rs==1) {
       	  alert.display("Type Changed to "+Type+" For Misison "+ID); 
		         
         }
		}
		catch (Exception ev){
			alert.display("Failed updating System");
		}
}
public void updateMissionPlanetSQL(String Planet,int ID,ActionEvent e) throws IOException {
	 try{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/gndsa","root","");
		    Statement stmt=con.createStatement();
		    String sql="UPDATE `mission` SET `MissionPlanet` = '"+Planet+"' WHERE `mission`.`MissionID` = "+ID+";";
		    int rs=stmt.executeUpdate(sql);
		    System.out.println(rs);
         if(rs==1) {
      		
       	  alert.display("Planet Name Changed to "+Planet+" For Misison "+ID);     
         }
		}
		catch (Exception ev){
			alert.display("Failed updating System");
		}
}
}
