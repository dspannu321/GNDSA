package application;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.ComboBox;
import javafx.stage.Stage;

public class CreateTeamController implements Initializable {
@FXML private ComboBox <Integer> member1;
@FXML private ComboBox <Integer> member2;
@FXML private ComboBox <Integer> member3;
ArrayList<Integer> empIds=new ArrayList<Integer>();
showAlert alert=new showAlert();
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		AddEmp();
		member1.getItems().addAll(empIds);
		member2.getItems().addAll(empIds);
		member3.getItems().addAll(empIds);
	}

	public void createButton(ActionEvent ev) throws IOException {
		int teamID = 0;
		if(verifyForSameID(member1.getValue(),member2.getValue(),member3.getValue())) {
		try{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/gndsa","root","");
		    Statement stmt=con.createStatement();
		    
		    String sql="INSERT INTO `Aerospaceteam` (`TeamID`, `Member1`, `Member2`, `Member3`,`MissionId`) VALUES (NULL, '"+member1.getValue()+"', '"+member2.getValue()+"', '"+member3.getValue()+"','0')";
		    int rs=stmt.executeUpdate(sql);
		    String createMail1="CREATE TABLE T"+member1.getValue()+" (SID INT,sendDate DATE,Subject VARCHAR (100),message TEXT (200))"; 
		    int r1=stmt.executeUpdate(createMail1);
		    String createMail2="CREATE TABLE T"+member2.getValue()+" (SID INT,sendDate DATE,Subject VARCHAR (100),message TEXT (200))";
		    int r2=stmt.executeUpdate(createMail2);
		    String createMail3="CREATE TABLE T"+member3.getValue()+" (SID INT,sendDate DATE,Subject VARCHAR (100),message TEXT (200))";
		    int r3=stmt.executeUpdate(createMail3);
		    String sqlgetTeamID="Select TeamID From aerospaceteam WHERE member1="+member1.getValue();
		    ResultSet resultgetTeam = stmt.executeQuery(sqlgetTeamID);
		    while(resultgetTeam.next())
		    {
		    	teamID=resultgetTeam.getInt("TeamID");
		    }
		    System.out.println(teamID);
		    SendEmail.sendAutomaticMailTeam(70001,member1.getValue(),"2018-11-26",teamID,member2.getValue(),member3.getValue());
		    SendEmail.sendAutomaticMailTeam(70001,member2.getValue(),"2018-11-26",teamID,member1.getValue(),member3.getValue());
		    SendEmail.sendAutomaticMailTeam(70001,member3.getValue(),"2018-11-26",teamID,member1.getValue(),member2.getValue());
		   
		    String sqlupdate="UPDATE `employee` SET `isAssigned` = '"+1+"' WHERE `employee`.`employee_ID` = '"+member1.getValue()+"' OR`employee`.`employee_ID` = '"+member2.getValue()+"' OR `employee`.`employee_ID` = '"+member3.getValue()+"'";
		    int result=stmt.executeUpdate(sqlupdate);
                 if(rs==1) {
              		alert.display("Team Created Successfully");
              		Stage window=(Stage)((Node)ev.getSource()).getScene().getWindow();
              		window.close();   
                 }
		    }
		
		catch (Exception e){
			System.out.println(e);
		} 
		}
		
	}
	
 public void AddEmp(){
	 int count=0;
	 try{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/gndsa","root","");
		    Statement stmt=con.createStatement();
		    String sql="Select * From `employee` where Department='Aerospace' AND Position ='Engineer' AND isAssigned='0'";
		    
		    ResultSet rs=stmt.executeQuery(sql);
		  while(rs.next()) {
		    int ID =rs.getInt("Employee_ID");
		    empIds.add(ID);
		    count++;
		    }
		  System.out.println(count);
		}
		catch (Exception e){
			System.out.println(e);;
		} 
	 
 }
 public boolean verifyForSameID(int id1, int id2, int id3) throws IOException {
	 if (id1==id2 && id1==id3)
	 {
		 alert.display("All Three Engineers Cannot be same");
		 return false;
	 }
	 else if(id1==id2) {
		 alert.display("Member 1 and Member 2 Cannot be Same Engineer");
		 return false;
	 }
	 else if(id1==id3) {
		 alert.display("Member 1 and Member 3 Cannot be Same Engineer");
		 return false;
	 }
	 else if(id2==id3) {
		 alert.display("Member 2 and Member 3 Cannot be Same Engineer");
		 return false;
	 }
	 else{
		 return true;
	 }
	 
 }

	
}
