package application;

import javafx.beans.property.SimpleStringProperty;

public class Research {

	Integer ResearchCode;
	SimpleStringProperty ResearchName;
	SimpleStringProperty ResearchField;
	SimpleStringProperty ResearchTopic;
	Integer EmployeeID;
	
	Research(int ResearchCode, String ResearchName, String ResearchField, String ResearchTopic, int EmployeeID){
		this.ResearchCode=new Integer(ResearchCode);
		this.ResearchName=new SimpleStringProperty(ResearchName);
		this.ResearchName=new SimpleStringProperty(ResearchField);
		this.ResearchName=new SimpleStringProperty(ResearchTopic);
		this.ResearchCode=new Integer(EmployeeID);
	}

	public Integer getResearchCode() {
		return ResearchCode;
	}

	public void setResearchCode(Integer researchCode) {
		ResearchCode = researchCode;
	}

	public String getResearchName() {
		return ResearchName.get();
	}

	public void setResearchName(SimpleStringProperty researchName) {
		ResearchName = researchName;
	}

	public String getResearchField() {
		return ResearchField.get();
	}

	public void setResearchField(SimpleStringProperty researchField) {
		ResearchField = researchField;
	}

	public String getResearchTopic() {
		return ResearchTopic.get();
	}

	public void setResearchTopic(SimpleStringProperty researchTopic) {
		ResearchTopic = researchTopic;
	}

	public Integer getEmployeeID() {
		return EmployeeID;
	}

	public void setEmployeeID(Integer employeeID) {
		EmployeeID = employeeID;
	}
	
	
}
