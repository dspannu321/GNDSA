package application;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class HRDashboardController implements Initializable {
@FXML TextField empName;
@FXML TextField empID;
@FXML
static Label user;
static int userID;
showAlert alert=new showAlert();
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		
		
	}
	//--------------------------------------------------------------Add New Employee----------------------------------------------------
	public void addEmployeeButton() throws IOException {
		try {
			FXMLLoader loader=new FXMLLoader();
			loader.setLocation(getClass().getResource("AddEmployee.fxml"));
			Parent dasboard=loader.load();
			Scene AddEmployee=new Scene(dasboard); 
			addEmployeeController controller=loader.getController();
			Stage addEmployeestage=new Stage();
			controller.setThisWindow(addEmployeestage);
			addEmployeestage.initModality(Modality.APPLICATION_MODAL);
			Image icon = new Image(getClass().getResourceAsStream("GNDSA.png"));
			addEmployeestage.getIcons().add(icon);
			addEmployeestage.setTitle("Add Employee");
			addEmployeestage.setScene(AddEmployee);
			addEmployeestage.showAndWait();
			}
			catch(Exception error) {	
			}
		}
	//------------------------------------------------------------------------------View Employee List------------------------------------
	public void allEmployeesButton(ActionEvent e) throws IOException {
		     Parent add = FXMLLoader.load(getClass().getResource("hrTableView.fxml"));
	         Scene empTable=new Scene(add);
	         Stage  EmployeeTableWindow=(Stage)((Node)e.getSource()).getScene().getWindow();
	         EmployeeTableWindow.setScene(empTable);
		
	}
//--------------------------------------------------------------------------------------View Profile--------------------------------------
	public void viewProfileButton() throws IOException {
		try {
			
			FXMLLoader loader=new FXMLLoader();
			loader.setLocation(getClass().getResource("EmployeeView.fxml"));
			Parent table=loader.load();
			Scene detailedScene=new Scene(table); 
			EmployeeView controller=loader.getController();
			controller.load(Integer.toString(userID));
			//System.out.println("table selected "+employeeTable.getSelectionModel().getSelectedItem().getFirstname().toString());
			Stage stage=new Stage();
			controller.setWindow(stage);
			stage.initModality(Modality.APPLICATION_MODAL);
			Image icon = new Image(getClass().getResourceAsStream("GNDSA.png"));
		    stage.getIcons().add(icon);
		    stage.setTitle(Integer.toString(userID));
			stage.setScene(detailedScene);
			stage.showAndWait();
			stage.close();
			
			}
			catch(Exception error) {
				//System.out.println(error);
				alert.display("Error Occured While loading your profile");
				
			}
		
	}
	//-----------------------------------------------------------------------------------Logout Function---------------------------------
	public void logoutButton(ActionEvent e) throws IOException {
		 if(alert.displayConfirm().equals("YES")) {
			 Parent add = FXMLLoader.load(getClass().getResource("Form.fxml"));
		     Scene login=new Scene(add);
		     Stage window=(Stage)((Node)e.getSource()).getScene().getWindow();
		     window.setScene(login); 
		 }
	}
	//---------------------------------------------------------------------Getters and setters---------------------------------------------
	public int getUserID() {
		return userID;
	}
	public static void setUserID(int ID) {
		userID = ID;
	}
	public static void setUserLabel(int userId) {
		user.setText("Welcome User "+Integer.toString(userId));
		
	}
	//-------------------------------------------------------------------Search Employee Function-----------------------------------------------
	public void searchButton() throws IOException {
		if (empName.getText().isEmpty() && empID.getText().isEmpty()) {
			alert.display("Enter Arguements to Search");	
		}
		
		else if (empName.getText().isEmpty()==false)
		{
		try{
			 
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/gndsa","root","");
		    Statement stmt=con.createStatement();
		    String sql="SELECT * FROM employee WHERE Employee_LName ='"+empName.getText()+"' OR Employee_FName='"+empName.getText()+"'";
		    ResultSet result=stmt.executeQuery(sql);
		    
	         if(result.next()) {
	        	 try {
	     			FXMLLoader loader=new FXMLLoader();
	     			loader.setLocation(getClass().getResource("SearchEmployeeTableController.fxml"));
	     			Parent dasboard=loader.load();
	     			Scene AddEmployee=new Scene(dasboard); 
	     			SearchEmployeeTable controller=loader.getController();
	     			Stage addEmployeestage=new Stage();
	     			controller.setWindow(addEmployeestage);
	     			controller.load(empName.getText());
	     			addEmployeestage.initModality(Modality.APPLICATION_MODAL);
	     			Image icon = new Image(getClass().getResourceAsStream("GNDSA.png"));
	     			addEmployeestage.getIcons().add(icon);
	     			addEmployeestage.setTitle("Employees");
	     			addEmployeestage.setScene(AddEmployee);
	     			addEmployeestage.showAndWait();
	     			}
	     			catch(Exception error) {	
	     			}
	     
	        	 }
	          
	          else {
	          	
	          	alert.display("No Record Found");	
	          }
		}
		catch (Exception ev){
			alert.display("No Record Found");	
		}
		}
		else if (empID.getText().isEmpty()==false && empName.getText().isEmpty())
		{
		try{
			 
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/gndsa","root","");
		    Statement stmt=con.createStatement();
		    String sql="SELECT * FROM employee WHERE Employee_ID ='"+empID.getText()+"'";
		    ResultSet result=stmt.executeQuery(sql);
		    
	        if(result.next()) {
	        	try {
	    			
	    			FXMLLoader loader=new FXMLLoader();
	    			loader.setLocation(getClass().getResource("EmployeeView.fxml"));
	    			Parent table=loader.load();
	    			Scene detailedScene=new Scene(table); 
	    			EmployeeView controller=loader.getController();
	    			controller.load(empID.getText());
	    			//System.out.println("table selected "+employeeTable.getSelectionModel().getSelectedItem().getFirstname().toString());
	    			Stage stage=new Stage();
	    			controller.setWindow(stage);
	    			stage.initModality(Modality.APPLICATION_MODAL);
	    			Image icon = new Image(getClass().getResourceAsStream("GNDSA.png"));
	    		    stage.getIcons().add(icon);
	    		    stage.setTitle(empID.getText());
	    			stage.setScene(detailedScene);
	    			stage.showAndWait();
	    			stage.close();
	    			
	    			}
	    			catch(Exception error) {
	    				//System.out.println(error);
	    				alert.display("No Employee Selected");
	    				
	    			}

	          }
	        else {
	        	
	        	alert.display("No Record Found");		
	        }
		}
		catch (Exception ev){
			alert.display("No Record Found");	
		}
		}
	}
	//---------------------------------------------------------------Clear button Function--------------------------------
	public void clearButton() {
		empName.clear();
		empID.clear();
		
	}
	

}
