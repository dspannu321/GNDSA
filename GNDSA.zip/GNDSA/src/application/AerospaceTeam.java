package application;

public class AerospaceTeam {
	
private int teamId;
private String Member1,Member2,Member3;
AerospaceTeam(int teamId, String Member1,String Member2, String Member3){
	this.Member1=Member1;
	this.Member2=Member2;
	this.Member3=Member3;
	this.teamId=teamId;
	
}
public int getTeamId() {
	return teamId;
}
public void setTeamId(int teamId) {
	this.teamId = teamId;
}
public String getMember1() {
	return Member1;
}
public void setMember1(String member1) {
	Member1 = member1;
}
public String getMember2() {
	return Member2;
}
public void setMember2(String member2) {
	Member2 = member2;
}
public String getMember3() {
	return Member3;
}
public void setMember3(String member3) {
	Member3 = member3;
}


}
