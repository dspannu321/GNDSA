package application;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;

public class SendEmail {
	static ArrayList<Integer> teamMembers=new ArrayList<Integer>();
	SendEmail(){}
	
	public static void sendAutomaticMailTeam(int senderID,int recID, String sendDate, int teamID,int member1,int member2) {//,String Subject,String Message,
		try{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/gndsa","root","");
		    Statement stmt=con.createStatement();
		    String sqlsendAutomaticMailTeam="INSERT INTO T"+recID+" (SID,sendDate,Subject,message) VALUES ('"+senderID+"','"+LocalDate.now()+"','Automatic mail From System.','You Have been Assigned to Team "+teamID+" With Group members "+member1+" And "+member2+"')";
		    int rssendmail=stmt.executeUpdate(sqlsendAutomaticMailTeam);
		}
		catch(Exception e) {
			System.out.println(e);
		}
		
	}
	public static void sendMailIndividual(int senderID,int recID, String sendDate, String subject,String message) {//,String Subject,String Message,
		try{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/gndsa","root","");
		    Statement stmt=con.createStatement();
		    String sqlsendAutomaticMailTeam="INSERT INTO T"+recID+" (SID,sendDate,Subject,message) VALUES ('"+senderID+"','"+LocalDate.now()+"','"
		    +subject+"','"+message+"')";
		    int rssendmail=stmt.executeUpdate(sqlsendAutomaticMailTeam);
		}
		catch(Exception e) {
			System.out.println(e);
		}
	
		
	}
    public static void sendBroadcastMail(int senderID, int teamID, String sendDate, String subject,String Message) {
    	try {
			teamMembers.clear();
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/gndsa","root","");
		    Statement stmt=con.createStatement();
		    String sqlgetTeamID="Select member1,member2,Member3 From aerospaceteam WHERE TeamID="+teamID;
		    ResultSet resultgetTeam = stmt.executeQuery(sqlgetTeamID);
		    while(resultgetTeam.next())
		    {
		    
		    	int member1=resultgetTeam.getInt("member1");
		    	teamMembers.add(member1);
		    	int member2=resultgetTeam.getInt("member2");
		    	teamMembers.add(member2);
		    	int member3=resultgetTeam.getInt("member3");
		    	teamMembers.add(member3);
		    }
		    SendEmail.sendMailIndividual(senderID, teamMembers.get(0), sendDate,subject,Message);
		    SendEmail.sendMailIndividual(senderID, teamMembers.get(1), sendDate,subject,Message);
		    SendEmail.sendMailIndividual(senderID, teamMembers.get(2), sendDate,subject,Message);
		    
		}
		catch(Exception e) {
			System.out.println(e);
		}
    	
	}
}
