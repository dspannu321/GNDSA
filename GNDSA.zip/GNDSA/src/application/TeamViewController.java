package application;

import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.ResourceBundle;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.stage.Stage;
import javafx.stage.Window;

public class TeamViewController implements Initializable{
@FXML private Label m1_EMPID;
@FXML private Label m2_EMPID;
@FXML private Label m3_EMPID;
@FXML private Label m1_EMPname;
@FXML private Label m2_EMPname;
@FXML private Label m3_EMPname;
@FXML private Label TeamID;
ArrayList<String> idL    = new ArrayList<String>();
ArrayList<String> nameL  = new ArrayList<String>();
Stage window;
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		
	}
	public void setData(int id) {
		m1_EMPID.setText(idL.get(0).toString());
		m2_EMPID.setText(idL.get(1).toString());
		m3_EMPID.setText(idL.get(2).toString());
		m1_EMPname.setText(nameL.get(0).toString());
		m2_EMPname.setText(nameL.get(1).toString());
		m3_EMPname.setText(nameL.get(2).toString());
		TeamID.setText(Integer.toString(id));
	}
	public void closeButton() {
		window.close();
	}
	public void setWindow(Stage window) {
		this.window = window;
	}
	public void load(int id) {
		
		
	try {
		     idL.clear();
		     nameL.clear();
				Class.forName("com.mysql.jdbc.Driver");
				Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/gndsa","root","");
			    Statement stmt=con.createStatement();
			    String sql="SELECT E.Employee_ID,E.Employee_FName,T.TeamID FROM employee E, aerospaceteam T WHERE T.TeamID='"+id
			    		+"' AND (T.Member1=E.Employee_ID OR T.Member2=E.Employee_ID OR T.Member3=E.Employee_ID)";
			    ResultSet rs=stmt.executeQuery(sql);
			    while(rs.next()) {
				String empID=rs.getString("Employee_ID");  
			    String ename=rs.getString("Employee_FName");
			    idL.add(empID);
			    nameL.add(ename);
			    }
			    System.out.println(idL);
			    System.out.println(nameL);
			    setData(id);
	}
			    catch(Exception e) {
			    	System.out.println(e);
			    }
			    
	}

}
