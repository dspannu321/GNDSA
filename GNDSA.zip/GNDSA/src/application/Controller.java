package application;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class Controller {
	
	@FXML
	TextField Username;
	@FXML
	PasswordField Password;
	@FXML
	Label outputLabel;
	@FXML
	showAlert alert=new showAlert();
	
		public void loginButtonClicked(ActionEvent ev) throws IOException {//login button start
			try{
				if(Username.getText().isEmpty()) {
			    	alert.display("Username cannot be Empty");
			    }
				else if(Password.getText().isEmpty()) {
			    	alert.display("Password cannot be Empty");
				}
				else {
					Class.forName("com.mysql.jdbc.Driver");
					Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/gndsa","root","");//create connection
				    Statement stmt=con.createStatement();
				    String sqlQueryHR="SELECT * FROM employee WHERE Employee_ID ='"+Username.getText()+"'AND passWord='"+Password.getText()+"' and Department ='HR'";
				    String sqlQueryAerospaceManager="SELECT * FROM employee WHERE Employee_ID ='"+Username.getText()+"'AND passWord='"+Password.getText()+"' and Department ='Aerospace' and Position='Manager'";
				    String sqlQueryAerospaceEngineer="SELECT * FROM employee WHERE Employee_ID ='"+Username.getText()+"'AND passWord='"+Password.getText()+"' and Department ='Aerospace' and Position='Engineer'";
				    String sqlQueryResearch="SELECT * FROM employee WHERE Employee_ID ='"+Username.getText()+"'AND passWord='"+Password.getText()+"' and Department ='Research'";
				    String sqlQueryOther="SELECT * FROM employee WHERE Employee_ID ='"+Username.getText()+"'AND passWord='"+Password.getText()+"'AND NOT Department ='Research' AND NOT Department ='Aerospace' AND NOT Department ='HR'";
				    outputLabel.setText("Validating your Info");
				    //-------------------------------------------------------Execution for HR employee-------------------------------------------------//
				    ResultSet resultHR=stmt.executeQuery(sqlQueryHR);// 
				    if (resultHR.next())
				    {
				    	
				         Parent add = FXMLLoader.load(getClass().getResource("HRDashboard.fxml"));
				         Scene HR=new Scene(add);
				         Stage HR_Dashboard=(Stage)((Node)ev.getSource()).getScene().getWindow();
				         HRDashboardController.setUserID(new Integer(Username.getText()));
				         HR_Dashboard.setScene(HR);
			    	}
				  //-------------------------------------------------------Execution for Aerospace Manager-------------------------------------------------//
				    ResultSet resultAerospaceMgr=stmt.executeQuery(sqlQueryAerospaceManager);
				    
				     if(resultAerospaceMgr.next()) {
				    	
				    	Parent add = FXMLLoader.load(getClass().getResource("AerospaceManagerDashboard.fxml"));
				         Scene Aerospace_Manager=new Scene(add);
				         Stage window=(Stage)((Node)ev.getSource()).getScene().getWindow();
				         window.setScene(Aerospace_Manager);  
				    }
				   //-------------------------------------------------------Execution for Aerospace Engineer-------------------------------------------------//
					    ResultSet resultAerospaceEng=stmt.executeQuery(sqlQueryAerospaceEngineer);
					    
					     if(resultAerospaceEng.next()) {
					    	
					    	Parent add = FXMLLoader.load(getClass().getResource("AerospaceEngineerDashboard.fxml"));
					         Scene addMission=new Scene(add);
					         Stage window=(Stage)((Node)ev.getSource()).getScene().getWindow();
					         AerospaceEngineerDashboardController.setUserID(new Integer(Username.getText()));
					        // AerospaceEngineerDashboardController.setUserLoggedIn();
					         System.out.println(Username.getText().toString());
					         window.setScene(addMission);  
					    }
				  //-------------------------------------------------------Execution for Research employee-------------------------------------------------//
				    ResultSet resultResearch=stmt.executeQuery(sqlQueryResearch);
				  
				    if(resultResearch.next()) {
				    	
				    	Parent add = FXMLLoader.load(getClass().getResource("Research.fxml"));
				         Scene research=new Scene(add);
				         Stage window=(Stage)((Node)ev.getSource()).getScene().getWindow();
				         window.setScene(research);
				    }
				    //-----------------------------------------------------Execution for all other employees----------------------------------------------//

				    ResultSet resultOther=stmt.executeQuery(sqlQueryOther);
				    if(resultOther.next()) 
				    {
				    	
				    	alert.display("User "+ Username.getText()+" not Authorized");
				    }
				    ResultSet resultnotEmp=stmt.executeQuery("Select * From employee WHERE employee_ID='"+Username.getText()+"' AND password ='"+Password.getText()+"'");
				    if (resultnotEmp.next()==false) {
				    	clearButtonClicked();
				         alert.display("Invalid UserID or Password");
				    }	
				}
			}
			//----------------------------------------------------------------
			catch (Exception e){
				System.out.println(e);
				alert.display("Connection With Database could not be Established");
			}
			//----------------------------------------------------------------
		}//login button ends
		
     
		public void clearButtonClicked() {
			Username.clear();
			Password.clear();
			outputLabel.setText("");
		}
		
}
