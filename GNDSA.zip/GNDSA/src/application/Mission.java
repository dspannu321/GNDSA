package application;

import javafx.beans.property.SimpleStringProperty;

public class Mission {
	Integer missionId;
SimpleStringProperty missionName;
SimpleStringProperty missionCategory;
SimpleStringProperty missionType;
SimpleStringProperty missionSubCat;
SimpleStringProperty missionPlanet;
SimpleStringProperty missionStatus;
Mission(int mID, String mName, String mCat, String mType, String mSubCat, String mPlanet, String mStatus){
	this.missionId=new Integer(mID);
	this.missionName= new SimpleStringProperty(mName);
	this.missionCategory=new SimpleStringProperty(mCat);
	this.missionType=new SimpleStringProperty(mType);
	this.missionSubCat=new SimpleStringProperty(mSubCat);
	this.missionPlanet=new SimpleStringProperty(mPlanet);
	this.missionStatus=new SimpleStringProperty(mStatus);
}

public Integer getMissionId() {
	return missionId;
}

public void setMissionId(Integer missionId) {
	this.missionId = missionId;
}

public String getMissionName() {
	return missionName.get();
}
public void setMissionName(String missionName) {
	this.missionName = new SimpleStringProperty(missionName);
}
public String getMissionCategory() {
	return missionCategory.get();
}
public void setMissionCategory(String missionCategory) {
	this.missionCategory = new SimpleStringProperty(missionCategory);
}
public String getMissionType() {
	return missionType.get();
}
public void setMissionType(String missionType) {
	this.missionType = new SimpleStringProperty(missionType);
}
public String getMissionSubCat() {
	return missionSubCat.get();
}
public void setMissionSubCat(String missionSubCat) {
	this.missionSubCat = new SimpleStringProperty(missionSubCat);
}
public String getMissionPlanet() {
	return missionPlanet.get();
}
public void setMissionPlanet(String missionPlanet) {
	this.missionPlanet = new SimpleStringProperty(missionPlanet);
}

public String getMissionStatus() {
	return missionStatus.get();
}

public void setMissionStatus(String missionStatus) {
	this.missionStatus = new SimpleStringProperty(missionStatus);
}


}
