package application;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class AerospacemanagerDashboardController implements Initializable{
@FXML TextField missionName;
@FXML TextField missionID;
static Label user;
static int userID;
showAlert alert=new showAlert();

@Override
public void initialize(URL arg0, ResourceBundle arg1) {
	// TODO Auto-generated method stub
	
}
public void addNewMissionButton() throws IOException {
	Stage stage=new Stage();
	stage.initModality(Modality.APPLICATION_MODAL);
	Parent root=FXMLLoader.load(getClass().getResource("AddMission.fxml"));
    Scene Scene1=new Scene(root);
    Image icon = new Image(getClass().getResourceAsStream("GNDSA.png"));
    stage.getIcons().add(icon);
    stage.setTitle("GNDSA Database");
	stage.setScene(Scene1);
	stage.showAndWait();
}
public void ViewAllMissionButton(ActionEvent e) throws IOException {
	Parent add = FXMLLoader.load(getClass().getResource("AllMissionsTable.fxml"));
    Scene empTable=new Scene(add);
    Stage  EmployeeTableWindow=(Stage)((Node)e.getSource()).getScene().getWindow();
    EmployeeTableWindow.setScene(empTable);
}
public void createTeamButton(ActionEvent e) throws IOException {
	 Parent add = FXMLLoader.load(getClass().getResource("AerospaceTeamTable.fxml"));
     Scene login=new Scene(add);
     Stage window=(Stage)((Node)e.getSource()).getScene().getWindow();
     window.setScene(login);
	
}
public void assignMissionButton(ActionEvent e) throws IOException {
	Parent add = FXMLLoader.load(getClass().getResource("AssignMissionToTeam.fxml"));
    Scene login=new Scene(add);
    Stage window=(Stage)((Node)e.getSource()).getScene().getWindow();
    AssignMissionToTeam.setWindow(window);
    window.setScene(login);
}
public void AssignLaunchVehicleButton(ActionEvent e) throws IOException {
	 try {
			
			FXMLLoader loader=new FXMLLoader();
			loader.setLocation(getClass().getResource("AssignLaunchVehicle.fxml"));
			Parent table=loader.load();
			Scene detailedScene=new Scene(table); 
			Stage stage=new Stage();
			stage.initModality(Modality.APPLICATION_MODAL);
			Image icon = new Image(getClass().getResourceAsStream("GNDSA.png"));
		    stage.getIcons().add(icon);
		    stage.setTitle(missionID.getText());
			stage.setScene(detailedScene);
			stage.showAndWait();
			stage.close();
			
		
		}
		catch(Exception error) {
			alert.display("No Employee Found");
		}
	
}

public void logoutButton(ActionEvent e) throws IOException {
	 if(alert.displayConfirm().equals("YES")) {
		 Parent add = FXMLLoader.load(getClass().getResource("Form.fxml"));
	     Scene login=new Scene(add);
	     Stage window=(Stage)((Node)e.getSource()).getScene().getWindow();
	     window.setScene(login); 
}
}
public void searchButton() throws IOException {
	if (missionName.getText().isEmpty() && missionID.getText().isEmpty()) {
		alert.display("Enter Arguements to Search");	
	}
	
	else if (missionName.getText().isEmpty()==false)
	{
	try{
		 
		Class.forName("com.mysql.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/gndsa","root","");
	    Statement stmt=con.createStatement();
	    String sql="SELECT * FROM mission WHERE MissionName ='"+missionName.getText()+"'";
	    ResultSet result=stmt.executeQuery(sql);
	    
         if(result.next()) {
        	 try {
     			
     			FXMLLoader loader=new FXMLLoader();
     			loader.setLocation(getClass().getResource("MissionView.fxml"));
     			Parent table=loader.load();
     			Scene detailedScene=new Scene(table); 
     			missionViewController controller=loader.getController();
     			controller.load(result.getInt("MissionID"));
     			Stage stage=new Stage();
     			controller.setWindow(stage);
     			stage.initModality(Modality.APPLICATION_MODAL);
     			Image icon = new Image(getClass().getResourceAsStream("GNDSA.png"));
     		    stage.getIcons().add(icon);
     		    stage.setTitle(missionID.getText());
     			stage.setScene(detailedScene);
     			stage.showAndWait();
     			stage.close();
     			
 			
 			}
 			catch(Exception error) {
 				//System.out.println(error);
 				alert.display("No Employee Found");
 				
 			}
     
        	 }
          
          else {
          	
          	alert.display("No Record Found");	
          }
	}
	catch (Exception ev){
		alert.display("No Record Found");	
	}
	}
	else if (missionID.getText().isEmpty()==false && missionName.getText().isEmpty())
	{
	try{
		 
		Class.forName("com.mysql.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/gndsa","root","");
	    Statement stmt=con.createStatement();
	    String sql="SELECT * FROM mission WHERE missionID ='"+missionID.getText()+"'";
	    ResultSet result=stmt.executeQuery(sql);
	    
        if(result.next()) {
        	try {
    			
        			FXMLLoader loader=new FXMLLoader();
        			loader.setLocation(getClass().getResource("MissionView.fxml"));
        			Parent table=loader.load();
        			Scene detailedScene=new Scene(table); 
        			missionViewController controller=loader.getController();
        			controller.load(new Integer(missionID.getText()));
        			Stage stage=new Stage();
        			controller.setWindow(stage);
        			stage.initModality(Modality.APPLICATION_MODAL);
        			Image icon = new Image(getClass().getResourceAsStream("GNDSA.png"));
        		    stage.getIcons().add(icon);
        		    stage.setTitle(missionID.getText());
        			stage.setScene(detailedScene);
        			stage.showAndWait();
        			stage.close();
        			
    			
    			}
    			catch(Exception error) {
    				//System.out.println(error);
    				alert.display("No Employee Found");
    				
    			}

          }
        else {
        	
        	alert.display("No Record Found");		
        }
	}
	catch (Exception ev){
		alert.display("No Record Found");	
	}
	}
}
public void clearButton() {
	missionName.clear();
	missionID.clear();
}


}
