package application;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class missionController  implements Initializable {
	@FXML TextField missionName;
	@FXML ComboBox<String> missionCategory;
	@FXML ComboBox<String> missionType;
	@FXML ComboBox<String> missionSubCat;
	@FXML ComboBox<String> missionPlanet;
	@FXML Label outputLabel;
	@FXML Button AddButton; 
	showAlert alert=new showAlert();
		@Override
		public void initialize(URL arg0, ResourceBundle arg1) {
		missionCategory.getItems().addAll("Planetary","Space","Deep-Space","Lunar");
		missionType.getItems().addAll("NA", "Fly-By","Gravity-Assist","Lander", "Rover", "Orbitter");
		missionSubCat.getItems().addAll("NA", "Space Telescope", "Communication Sattelite","Space Lab");
		missionPlanet.getItems().addAll("Mercury","Venus","Mars","Jupiter");
		
		
		//System.out.println(missionCategory.getValue().toString());
		/*if(missionCategory.getValue().toString().equals("Planetary")) {
			missionPlanet.getItems().addAll("Mercury","Venus","Mars","Jupiter");
			missionSubCat.getItems().addAll("NA");
			missionType.getItems().addAll("Impact","Rover","Orbiter","Fly-By","Gravity Assist");
		}
		else if(missionCategory.getValue().toString().equals("Space")) {
			missionSubCat.getItems().addAll("Space telescope", "Communication Sattelite","Space Lab");	
			missionType.getItems().addAll("NA");
			missionPlanet.getItems().addAll("NA");
		}
		else if(missionCategory.getValue().toString().equals("Deep-Space")) {
			missionType.getItems().addAll("NA","Fly-By","Gravity Assist");
			missionPlanet.getItems().addAll("Mercury","Venus","Mars","Jupiter");
			missionSubCat.getItems().addAll("NA");
		}
		else {
			missionType.getItems().add("");
			missionSubCat.getItems().add("");
			missionPlanet.getItems().add("");
		}*/
		
		
		}

		public void AddButtonClicked(ActionEvent e) throws IOException {
			if(missionName.getText().isEmpty() || missionCategory.getValue().isEmpty() || missionSubCat.getValue().isEmpty() || missionType.getValue().isEmpty() || missionPlanet.getValue().isEmpty()) {
				
				alert.display("Fields cannot be left blank");
				
			}
			if(verifyPlanet(missionCategory.getValue().toString(),missionPlanet.getValue().toString()))
			{
			try{
				 
					Class.forName("com.mysql.jdbc.Driver");
					Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/gndsa","root","");
				    Statement stmt=con.createStatement();
				    String sqlVer="SELECT * FROM `mission` WHERE `MissionName` = '"+missionName.getText()+"'";
				    ResultSet result=stmt.executeQuery(sqlVer);
				    if(result.next()) {
				    	alert.display("Mission \"" + missionName.getText()+ "\" Already Exists"); 
				    }
				    else {
				    String sql="INSERT INTO `mission` (`MissionID`, `MissionName`, `MissionCat`, `MissionSubCat`, `MissionType`, `MissionPlanet`) VALUES (NULL, '"+missionName.getText()+"', '"+missionCategory.getValue().toString()+"', '"+missionSubCat.getValue().toString()+"', '"+missionType.getValue().toString()+"','"+missionPlanet.getValue().toString()+"')";
				    int rs=stmt.executeUpdate(sql);
				    System.out.println(rs);
                         if(rs==1) {
 
                      		alert.display("Mission \"" + missionName.getText()+ "\" Added Successfully");
                      		Stage window=(Stage)((Node)e.getSource()).getScene().getWindow();
                      		window.close();
        			         
                         }
				}
			 }
				catch (Exception ev){
				alert.display("Fields cannot be left blank");
				}
			}
			 
		}
		public boolean verifyPlanet(String cat,String planet) throws IOException {
			if(cat.equals("Planetary")&&planet.equals("NA"))
			{
				alert.display("Planet must be selected for Planetary missions");
				return false;
			}
			return true;
		}

	
}
