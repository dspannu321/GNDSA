package application;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.ResourceBundle;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class CreateMailController implements Initializable{
@FXML private ComboBox <Integer>selectRec;
@FXML private TextField Subject;
@FXML private TextArea Message;
ArrayList<Integer> teamMembers=new ArrayList<Integer>();
showAlert alert=new showAlert();
static int userLoggedIn;
Stage window;
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		
		
	}
	public void sendButton() throws IOException {
		try {
			
			SendEmail.sendMailIndividual(userLoggedIn, selectRec.getValue(), "2018-11-26", Subject.getText(),Message.getText());
			alert.display("Message Sent");
			window.close();
		}
		catch (Exception e){
			System.out.println(e);
		}
		
	}
	public void getteamMembers(int user) {
		System.out.println("User Logged in getteam members = " +user);
		try {
			teamMembers.clear();
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/gndsa","root","");
		    Statement stmt=con.createStatement();
		    String sqlgetTeamID="Select TeamID,member1,member2,Member3 From aerospaceteam WHERE member1='"+user+"' OR member2='"+user+"' OR member3='"+user+"'";
		    ResultSet resultgetTeam = stmt.executeQuery(sqlgetTeamID);
		    while(resultgetTeam.next())
		    {
		    	int teamID=resultgetTeam.getInt("TeamID");
		    	teamMembers.add(teamID);
		    	int member1=resultgetTeam.getInt("member1");
		    	teamMembers.add(member1);
		    	int member2=resultgetTeam.getInt("member2");
		    	teamMembers.add(member2);
		    	int member3=resultgetTeam.getInt("member3");
		    	teamMembers.add(member3);
		    }
		    //System.out.println(teamMembers);
		    selectRec.getItems().addAll(teamMembers);
		}
		catch(Exception e) {
			System.out.println(e);
		}
	}
	public void setWindow(Stage stage) {
		window=stage;// TODO Auto-generated method stub
		
	}
	public void setuser(int userLogged) {
		userLoggedIn=userLogged;// TODO Auto-generated method stub
		
	}
}
