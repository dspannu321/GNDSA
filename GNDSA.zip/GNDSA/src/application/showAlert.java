package application;

import java.io.IOException;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class showAlert {
	showAlert(){		
	}

	
	public  void display(String message) throws IOException {
		
		FXMLLoader loader=new FXMLLoader();
		loader.setLocation(getClass().getResource("AlertBox.fxml"));
		Parent table=loader.load();
		Scene detailedScene=new Scene(table); 
		AlertBox controller=loader.getController();
		controller.setLableText(message);
		Stage stage=new Stage();
		stage.initModality(Modality.APPLICATION_MODAL);
		Image icon = new Image(getClass().getResourceAsStream("GNDSA.png"));
	    stage.getIcons().add(icon);
	    stage.setTitle("GNDSA");
		stage.setScene(detailedScene);
		stage.showAndWait();
		
	}
	public String displayConfirm() throws IOException {
		
		FXMLLoader loader=new FXMLLoader();
		loader.setLocation(getClass().getResource("ConfirmationAlert.fxml"));
		Parent p=loader.load();
		Scene displayconfirmationBox=new Scene(p); 
		confirmation controller=loader.getController();
		Stage stage=new Stage();
		stage.initModality(Modality.APPLICATION_MODAL);
		Image icon = new Image(getClass().getResourceAsStream("GNDSA.png"));
	    stage.getIcons().add(icon);
	    stage.setTitle("GNDSA");
		stage.setScene(displayconfirmationBox);
		stage.showAndWait();
		return controller.getOutput();
	}
	public String printConfirm(String message) throws IOException {
		
		FXMLLoader loader=new FXMLLoader();
		loader.setLocation(getClass().getResource("ConfirmationAlert.fxml"));
		Parent p=loader.load();
		Scene displayconfirmationBox=new Scene(p); 
		confirmation controller=loader.getController();
		controller.setLabel(message);
		Stage stage=new Stage();
		stage.initModality(Modality.APPLICATION_MODAL);
		Image icon = new Image(getClass().getResourceAsStream("GNDSA.png"));
	    stage.getIcons().add(icon);
	    stage.setTitle("GNDSA");
		stage.setScene(displayconfirmationBox);
		stage.showAndWait();
		return controller.getOutput();
	}

	
}
