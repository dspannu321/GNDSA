package application;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ResourceBundle;

import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

public class HrController implements Initializable {
	@FXML
	TextField FirstName;
	@FXML
	TextField Lastname;
	@FXML
	ComboBox<String> Department;
	@FXML
	TextField Password;
	@FXML
	Label outputLabel;
@FXML
private TableView<Employee> table;
@FXML
private TableColumn<Employee,Integer> empID;
@FXML
private TableColumn<Employee,String> fName;
@FXML
private TableColumn<Employee,String> lName;
@FXML
private TableColumn<Employee,String> Dept;
@FXML
private TableColumn<Employee,String> Pass;

	
	showAlert alert=new showAlert();
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		
		empID.setCellValueFactory(new PropertyValueFactory<Employee, Integer>("id"));
		fName.setCellValueFactory(new PropertyValueFactory<Employee, String>("firstname"));
		lName.setCellValueFactory(new PropertyValueFactory<Employee,String>("lastname"));
		Dept.setCellValueFactory(new PropertyValueFactory<Employee, String>("Department"));
		Pass.setCellValueFactory(new PropertyValueFactory<Employee, String>("password"));
		table.setItems(getEmployee());
		
	}
public ObservableList<Employee> getEmployee(){
	ObservableList<Employee> emp=FXCollections.observableArrayList();
	try{
		Class.forName("com.mysql.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/gndsa","root","");
	    Statement stmt=con.createStatement();
	    String sql="Select * From `employee`";
	    ResultSet rs=stmt.executeQuery(sql);
	  while(rs.next()) {
	    int ID =rs.getInt("Employee_ID");
	    String nameF=rs.getString("Employee_Fname");
	    String nameL=rs.getString("Employee_LName");
	    String dept=rs.getString("Department");
	    String Pass=rs.getString("passWord");
	    Date DOB=rs.getDate("Dob");
	    String pos=rs.getString("Position");
	    emp.add(new Employee (ID,nameF,nameL,Pass,dept,pos,DOB));
	    }
	}
	catch (Exception e){
		System.out.println(e);;
	}
	
	return emp;
}
 public void addEmployeeButtonClicked(ActionEvent e) throws IOException {
	 
	 Parent add = FXMLLoader.load(getClass().getResource("EmployeeTable.fxml"));
     Scene addEmp=new Scene(add);
     Stage window=(Stage)((Node)e.getSource()).getScene().getWindow();
     window.setScene(addEmp);   
	
		}
 public void logoutButtonClicked(ActionEvent ev)throws IOException {
	 if(alert.displayConfirm().equals("YES")) {
	 Parent add = FXMLLoader.load(getClass().getResource("Form.fxml"));
     Scene addEmp=new Scene(add);
     Stage window=(Stage)((Node)ev.getSource()).getScene().getWindow();
     window.setScene(addEmp); 
 }
 }
 
 }

	
