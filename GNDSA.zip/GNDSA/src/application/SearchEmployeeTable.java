package application;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.fxml.Initializable;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class SearchEmployeeTable implements Initializable {

		
		@FXML private TableView<Employee> employeeTable;
		@FXML private TableColumn<Employee,Integer> empID;
		@FXML private TableColumn<Employee,String> fName;
		@FXML private TableColumn<Employee,String> lName;
		@FXML private TableColumn<Employee,String> Dept;
		@FXML private TableColumn<Employee,Date> DOB;
		ObservableList<Employee> emp=FXCollections.observableArrayList();
		showAlert alert=new showAlert();
		Stage window;
		@Override
		public void initialize(URL arg0, ResourceBundle arg1) {
			empID.setCellValueFactory(new PropertyValueFactory<Employee, Integer>("id"));
			fName.setCellValueFactory(new PropertyValueFactory<Employee, String>("firstname"));
			lName.setCellValueFactory(new PropertyValueFactory<Employee,String>("lastname"));
			Dept.setCellValueFactory(new PropertyValueFactory<Employee, String>("Department"));
			//Pass.setCellValueFactory(new PropertyValueFactory<Employee, String>("password"));
			employeeTable.setItems(getEmployee());	
		}
		public ObservableList<Employee> getEmployee(){
			//load();
			
			return emp;
		}
		public void openButton() throws IOException {
			try {
				
				FXMLLoader loader=new FXMLLoader();
				loader.setLocation(getClass().getResource("EmployeeView.fxml"));
				Parent table=loader.load();
				Scene detailedScene=new Scene(table); 
				EmployeeView controller=loader.getController();
				controller.setData(employeeTable.getSelectionModel().getSelectedItem());
				System.out.println("table selected "+employeeTable.getSelectionModel().getSelectedItem().getFirstname().toString());
				Stage stage=new Stage();
				controller.setWindow(stage);
				stage.initModality(Modality.APPLICATION_MODAL);
				Image icon = new Image(getClass().getResourceAsStream("GNDSA.png"));
			    stage.getIcons().add(icon);
			    stage.setTitle(employeeTable.getSelectionModel().getSelectedItem().getFirstname().toString());
				stage.setScene(detailedScene);
				stage.showAndWait();
				stage.close();
				
				}
				catch(Exception error) {
					//System.out.println(error);
					alert.display("No Employee Selected");
					
				}
			}
			
		
		
		public void terminateButton(ActionEvent e) throws IOException {
			try {
				
				   int id= employeeTable.getSelectionModel().getSelectedItem().getId();
				   System.out.println(id);
				   if(alert.displayConfirm().equals("YES")) {
					   try{
							 
							Class.forName("com.mysql.jdbc.Driver");
							Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/gndsa","root","");
						    Statement stmt=con.createStatement();
						    String sql="DELETE from employee WHERE Employee_ID='"+id+"'";
						    int rs=stmt.executeUpdate(sql);
						    System.out.println(rs);
			              if(rs==1) {
			            	  alert.display("Employee "+id+ " Terminated");
			            	  //load();
			              }
			              
						}
						catch (Exception ev){
							alert.display("Failed to Terminate Employee");
						}    
				   }
					
					}
					catch(Exception error) {
						alert.display("No Record Selected");
						
					}
		}
		
		public void closeButton(ActionEvent e) throws IOException {
			
			   window.close();
		}
		
	public void load(String lsName) {
		try{
			emp.clear();
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/gndsa","root","");
		    Statement stmt=con.createStatement();
		    String sql="Select * From `employee` where Employee_LName='"+lsName+"' OR Employee_FName='"+lsName+"'";
		    ResultSet rs=stmt.executeQuery(sql);
		  while(rs.next()) {
		    int ID =rs.getInt("Employee_ID");
		    String nameF=rs.getString("Employee_Fname");
		    String nameL=rs.getString("Employee_LName");
		    String dept=rs.getString("Department");
		    String Pass=rs.getString("passWord");
		    Date DOB=rs.getDate("Dob");
		    String pos=rs.getString("Position");
		    emp.add(new Employee (ID,nameF,nameL,Pass,dept,pos,DOB));
		    }
		}
		catch (Exception e){
			System.out.println(e);;
		}
		
		
	}
	public Stage getWindow() {
		return window;
	}
	public void setWindow(Stage window) {
		this.window = window;
	}
	
	}



