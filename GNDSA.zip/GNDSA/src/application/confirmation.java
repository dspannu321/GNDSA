package application;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.stage.Stage;

public class confirmation implements Initializable {
	
	
	String output;
	@FXML
	
    Label label;
	 
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		label.setText("Are You Sure ?");
	}
	public void yesButton(ActionEvent e) {
		 Stage window=(Stage)((Node)e.getSource()).getScene().getWindow();
		 window.close();
		setOutput("YES");
		
	}
	public void noButton(ActionEvent e) {
		 Stage window=(Stage)((Node)e.getSource()).getScene().getWindow();
		 window.close();
	setOutput("NO");
	}
	
	public String getOutput() {
		return output;
	}
	public void setOutput(String output) {
		this.output = output;
	}
	public void setLabel(String message) {
		label.setText(message);
		
	}
}
