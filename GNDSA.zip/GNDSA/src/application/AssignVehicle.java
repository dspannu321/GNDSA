package application;

public class AssignVehicle {

}
