package application;
	
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;


public class Main extends Application {
	
	@Override
	public void start(Stage stage) throws Exception {
		try {
		Parent root=FXMLLoader.load(getClass().getResource("Form.fxml"));
	    Scene Scene1=new Scene(root);
	    Image icon = new Image(getClass().getResourceAsStream("GNDSA.png"));
	    stage.getIcons().add(icon);
	    stage.setTitle("GNDSA Database");
		stage.setScene(Scene1);
		stage.show();
		}
		catch(Exception e) {
			System.out.println("Exception in Main Class");
		}
	}
	public static void main(String[] args) {
		launch();
	}

}
