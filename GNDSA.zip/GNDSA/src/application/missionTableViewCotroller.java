package application;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumn.CellEditEvent;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.ComboBoxTableCell;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.image.Image;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class missionTableViewCotroller implements Initializable {
	@FXML private TableView <Mission> missionTable;
	@FXML private TableColumn<Mission,Integer> missionID;
	@FXML private TableColumn<Mission,String> missionName;
	@FXML private TableColumn<Mission,String> missionCategory;
	@FXML private TableColumn<Mission,String> missionType;
	@FXML private TableColumn <Mission,String> missionSubCat;
	@FXML private TableColumn<Mission,String> missionPlanet;
	@FXML private TableColumn <Mission,String>missionStatus;
	@FXML private MenuItem open;
	@FXML private MenuItem logoutButton;
	int count=0;
	ObservableList<Mission> mission=FXCollections.observableArrayList();
	showAlert alert=new showAlert();
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		missionID.setCellValueFactory(new PropertyValueFactory<Mission,Integer>("missionId"));
		missionName.setCellValueFactory(new PropertyValueFactory<Mission,String>("missionName"));
		missionCategory.setCellValueFactory(new PropertyValueFactory<Mission,String>("missionCategory"));
		missionType.setCellValueFactory(new PropertyValueFactory<Mission,String>("missionType"));
		missionSubCat.setCellValueFactory(new PropertyValueFactory<Mission,String>("missionSubCat"));
		missionPlanet.setCellValueFactory(new PropertyValueFactory<Mission,String>("missionPlanet"));
		missionStatus.setCellValueFactory(new PropertyValueFactory<Mission,String>("missionStatus"));
		missionTable.setItems(getMission());
		missionTable.setEditable(true);
		missionName.setCellFactory(TextFieldTableCell.forTableColumn());
		missionCategory.setCellFactory(ComboBoxTableCell.forTableColumn("Planetary","Space","Deep-Space","Lunar"));
		missionSubCat.setCellFactory(ComboBoxTableCell.forTableColumn("NA","Space telescope", "Communication Sattelite","Space Lab"));
		missionType.setCellFactory(ComboBoxTableCell.forTableColumn("NA","Impact", "Rover","Lander","Orbiter","Fly-By","Gravity Assist"));
		missionPlanet.setCellFactory(ComboBoxTableCell.forTableColumn("NA","Mercury","Venus","Mars","Jupiter"));
		
	}
	public ObservableList<Mission> getMission(){
		load();
		return mission;
		
	}
	public void searchMission()throws Exception {
		
		Stage stage=new Stage();
		stage.initModality(Modality.APPLICATION_MODAL);
		Parent root=FXMLLoader.load(getClass().getResource("SearchMission.fxml"));
	    Scene Scene1=new Scene(root);
	    Image icon = new Image(getClass().getResourceAsStream("GNDSA.png"));
	    stage.getIcons().add(icon);
	    stage.setTitle("Search");
		stage.setScene(Scene1);
		stage.showAndWait(); 
		
	}
	//--------------------------------------------------------------------------------------------------------------------------
	public void changemissionName(CellEditEvent editCell) throws ClassNotFoundException, SQLException, IOException 
	{
		Mission selected=missionTable.getSelectionModel().getSelectedItem();
		selected.setMissionName(editCell.getNewValue().toString());
		updateMissionNameSQL(editCell.getNewValue().toString(),selected.getMissionId(),null);  
	}
	//-----------------------------------------------------------------------------------------------------------------------
	public void changemissioCat(CellEditEvent editCell) throws IOException 
	{
		Mission selected=missionTable.getSelectionModel().getSelectedItem();
		selected.setMissionCategory(editCell.getNewValue().toString());
		updateMissionCategorySQL(editCell.getNewValue().toString(),selected.getMissionId(),null);
	}
	//--------------------------------------------------------------------------------------------------------------------------
	public void changemissionSubCat(CellEditEvent editCell) throws ClassNotFoundException, SQLException, IOException 
	{
			Mission selected=missionTable.getSelectionModel().getSelectedItem();
			selected.setMissionSubCat(editCell.getNewValue().toString());
			updateMissionSubCatSQL(editCell.getNewValue().toString(),selected.getMissionId(),null);  
	}
	//--------------------------------------------------------------------------------------------------------------------------
	public void changemissionType(CellEditEvent editCell) throws ClassNotFoundException, SQLException, IOException 
	{
			Mission selected=missionTable.getSelectionModel().getSelectedItem();
			selected.setMissionType(editCell.getNewValue().toString());
			updateMissionTypeSQL(editCell.getNewValue().toString(),selected.getMissionId(),null);  
	}
	//--------------------------------------------------------------------------------------------------------------------------
	public void changemissionPlanet(CellEditEvent editCell) throws ClassNotFoundException, SQLException, IOException 
	{
			Mission selected=missionTable.getSelectionModel().getSelectedItem();
			selected.setMissionPlanet(editCell.getNewValue().toString());
			updateMissionPlanetSQL(editCell.getNewValue().toString(),selected.getMissionId(),null);   
	}
	//-----------------------------------------------------------------------------------------------------------------------
	public void updateMissionNameSQL(String Name,int ID,ActionEvent e) throws IOException {
	
		 try{
			 
				Class.forName("com.mysql.jdbc.Driver");
				Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/gndsa","root","");
			    Statement stmt=con.createStatement();
			    String sqlVer="SELECT * FROM `mission` WHERE `MissionName` = '"+Name+"'";
			    ResultSet result=stmt.executeQuery(sqlVer);
			    if(result.next()) {
			    	alert.display("Mission \"" + Name+ "\" Already Exists");	
			    	load();
			    }
			    else {
			    String sql="UPDATE `mission` SET `MissionName` = '"+Name+"' WHERE `mission`.`MissionID` = "+ID+";";
			    int rs=stmt.executeUpdate(sql);
			    System.out.println(rs);
                  if(rs==1) {

                	  showAlert("Name Changed to "+Name+" For Misison "+ID);  

                  }
			}
		 }
			catch (Exception ev){
				showAlert("Failed updating System"); 
			}
		 
	}
	public void updateMissionCategorySQL(String Cat,int ID,ActionEvent e) throws IOException {
		 try{
			 
				Class.forName("com.mysql.jdbc.Driver");
				Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/gndsa","root","");
			    Statement stmt=con.createStatement();
			    String sql="UPDATE `mission` SET `MissionCat` = '"+Cat+"' WHERE `mission`.`MissionID` = "+ID+";";
			    int rs=stmt.executeUpdate(sql);
			    System.out.println(rs);
               if(rs==1) {

            	   showAlert("Category Changed to "+Cat+" For Misison "+ID);  
			         
               }
			}
			catch (Exception ev){
				showAlert("Failed updating System"); 
			}
	}
	
	public void updateMissionSubCatSQL(String SubCat,int ID,ActionEvent e) throws IOException {
		 try{
			 
				Class.forName("com.mysql.jdbc.Driver");
				Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/gndsa","root","");
			    Statement stmt=con.createStatement();
			    String sql="UPDATE `mission` SET `MissionSubCat` = '"+SubCat+"' WHERE `mission`.`MissionID` = "+ID+";";
			    int rs=stmt.executeUpdate(sql);
			    System.out.println(rs);
              if(rs==1) {

            	  showAlert("Sub-Category Changed to "+SubCat+" For Misison "+ID); 
			         
              }
			}
			catch (Exception ev){
				showAlert("Failed updating System"); 
			}
	}
	public void updateMissionTypeSQL(String Type,int ID,ActionEvent e) throws IOException {
		 try{
			 
				Class.forName("com.mysql.jdbc.Driver");
				Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/gndsa","root","");
			    Statement stmt=con.createStatement();
			    String sql="UPDATE `mission` SET `MissionType` = '"+Type+"' WHERE `mission`.`MissionID` = "+ID+";";
			    int rs=stmt.executeUpdate(sql);
			    System.out.println(rs);
              if(rs==1) {
            	  showAlert("Type Changed to "+Type+" For Misison "+ID); 
			         
              }
			}
			catch (Exception ev){
				showAlert("Failed updating System");
			}
	}
	public void updateMissionPlanetSQL(String Planet,int ID,ActionEvent e) throws IOException {
		 try{
				Class.forName("com.mysql.jdbc.Driver");
				Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/gndsa","root","");
			    Statement stmt=con.createStatement();
			    String sql="UPDATE `mission` SET `MissionPlanet` = '"+Planet+"' WHERE `mission`.`MissionID` = "+ID+";";
			    int rs=stmt.executeUpdate(sql);
			    System.out.println(rs);
              if(rs==1) {
           		
            	  showAlert("Planet Name Changed to "+Planet+" For Misison "+ID);     
              }
			}
			catch (Exception ev){
				showAlert("Failed updating System");
			}
	}
	
	public void openButton(ActionEvent e) throws IOException {
		try {
		FXMLLoader loader=new FXMLLoader();
		loader.setLocation(getClass().getResource("MissionView.fxml"));
		Parent table=loader.load();
		Scene detailedScene=new Scene(table); 
		missionViewController controller=loader.getController();
		controller.setData(missionTable.getSelectionModel().getSelectedItem());
		Stage stage=new Stage();
		controller.setWindow(stage);
		stage.initModality(Modality.APPLICATION_MODAL);
		Image icon = new Image(getClass().getResourceAsStream("GNDSA.png"));
	    stage.getIcons().add(icon);
	    stage.setTitle(missionTable.getSelectionModel().getSelectedItem().getMissionName().toString());
		stage.setScene(detailedScene);
		stage.showAndWait();
		stage.close();
		
		}
		catch(Exception error) {
			showAlert("No Record Selected");
			
		}
	}
	
	public void backButtonClicked(ActionEvent e)throws IOException {
		Parent add = FXMLLoader.load(getClass().getResource("AerospaceManagerDashboard.fxml"));
        Scene hrDashboard=new Scene(add);
        Stage  hrDasboardView=(Stage)((Node)e.getSource()).getScene().getWindow();
        hrDasboardView.setScene(hrDashboard);
	 }
	public void deleteMission(ActionEvent e) throws IOException {
		
		try {
			
		   int id= missionTable.getSelectionModel().getSelectedItem().getMissionId();
		   System.out.println(id);
		   if(alert.displayConfirm().equals("YES")) {
			   try{
					 
					Class.forName("com.mysql.jdbc.Driver");
					Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/gndsa","root","");
				    Statement stmt=con.createStatement();
				    String sql="DELETE from mission WHERE missionID='"+id+"'";
				    int rs=stmt.executeUpdate(sql);
				    System.out.println(rs);
	              if(rs==1) {
	            	  showAlert("Mission "+id+ " Deleted");
	            	  load();
	              }
	              
				}
				catch (Exception ev){
					showAlert("Failed to Delete mission");
				}    
		   }
			
			}
			catch(Exception error) {
				showAlert("No Record Selected");
				
			}
		 
		
	}
	
	public void showAlert(String message) throws IOException {
		
		alert.display(message);
		
	}
	public void load() {
		try{
			mission.clear();
			count=0;
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/gndsa","root","");
		    Statement stmt=con.createStatement();
		    String sql="Select * From `mission`";
		    ResultSet rs=stmt.executeQuery(sql);
		  while(rs.next()) {
		    int ID =rs.getInt("MissionID");
		    String mName=rs.getString("MissionName");
		    String mCat=rs.getString("MissionCat");
		    String mSubCat=rs.getString("MissionSubCat");
		    String mType=rs.getString("MissionType");
		    String mPlanet=rs.getString("MissionPlanet");
		    String mStatus=rs.getString("MissionStatus");
		    mission.add(new Mission (ID,mName,mCat,mType,mSubCat,mPlanet,mStatus));
		    count++;
		    
		    }
		  System.out.println("total missions= " +count);
		}
		catch (Exception e){
			System.out.println(e);;
		}
	}
	}	
		



