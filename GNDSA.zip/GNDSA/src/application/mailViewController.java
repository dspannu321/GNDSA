package application;

import java.sql.Date;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.stage.Stage;

public class mailViewController {
	@FXML private Label From;
	@FXML private Label Dt;
	@FXML private Label Subject;
	@FXML private Label message;
	Stage window;
	Email selected_mail;
	
	public void setData(Email mail) {
	selected_mail=mail;
	From.setText(Integer.toString(selected_mail.getSenderID()));
	Dt.setText(selected_mail.getSendDate().toString());
	Subject.setText(selected_mail.getSubject());
	message.setText(selected_mail.getMessage());
	}
	public void load() {
		
	}
	public void setWindow(Stage win) {
		window=win;
	}
	public void close() {
	window.close();	
	}
	

}
