package application;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class AerospaceTeamController implements Initializable {

	@FXML 
	private TableView<AerospaceTeam> table;
	@FXML 
	private TableColumn <AerospaceTeam,Integer> teamId;
	@FXML
	private TableColumn<AerospaceTeam,String>Member1;
	@FXML
	private TableColumn<AerospaceTeam,String>Member2;
	@FXML
	private TableColumn<AerospaceTeam,String>Member3;
	ObservableList<AerospaceTeam> team=FXCollections.observableArrayList();
	showAlert alert=new showAlert();
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		teamId.setCellValueFactory(new PropertyValueFactory<AerospaceTeam,Integer>("teamId"));
		Member1.setCellValueFactory(new PropertyValueFactory<AerospaceTeam,String>("Member1"));
		Member2.setCellValueFactory(new PropertyValueFactory<AerospaceTeam,String>("Member2"));
		Member3.setCellValueFactory(new PropertyValueFactory<AerospaceTeam,String>("Member3"));
		table.setItems(getTeam());
		
	}
	public ObservableList<AerospaceTeam> getTeam(){
		load();
		return team;
	}
	public void createTeamButton() throws IOException {
		Stage stage=new Stage();
		stage.initModality(Modality.APPLICATION_MODAL);
		Parent root=FXMLLoader.load(getClass().getResource("CreateTeam.fxml"));
	    Scene Scene1=new Scene(root);
	    Image icon = new Image(getClass().getResourceAsStream("GNDSA.png"));
	    stage.getIcons().add(icon);
	    stage.setTitle("GNDSA Database");
		stage.setScene(Scene1);
		stage.showAndWait();
		load();
		
	}
	public void openButton() throws IOException {	
try {

            int id= table.getSelectionModel().getSelectedItem().getTeamId();
			FXMLLoader loader=new FXMLLoader();
			loader.setLocation(getClass().getResource("TeamView.fxml"));
			Parent table=loader.load();
			Scene detailedScene=new Scene(table); 
			TeamViewController controller=loader.getController();
			Stage stage=new Stage();
			controller.setWindow(stage);
			controller.load(id);
			stage.initModality(Modality.APPLICATION_MODAL);
			Image icon = new Image(getClass().getResourceAsStream("GNDSA.png"));
		    stage.getIcons().add(icon);
		    stage.setTitle(Integer.toString(id));
			stage.setScene(detailedScene);
			stage.showAndWait();
			stage.close();
			
			}
			catch(Exception error) {
				System.out.println(error);
				alert.display("No Team Selected");
				
			}
		
	}
	public void deleteButton() throws IOException {
		int mem1 = 0,mem2=0,mem3=0;
		try {
			
			   int id= table.getSelectionModel().getSelectedItem().getTeamId();
			   System.out.println(id);
			   if(alert.displayConfirm().equals("YES")) {
				   try{
						 
						Class.forName("com.mysql.jdbc.Driver");
						Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/gndsa","root","");
					    Statement stmt=con.createStatement();
					    String sqlChangeIsAssignedMis="UPDATE mission SET MissionStatus='0' WHERE MissionID =(SELECT MissionID from aerospaceteam WHERE TeamID="+id+")";
					    int doneAss=stmt.executeUpdate(sqlChangeIsAssignedMis);
					    String sqlChangeIsAssigned1="UPDATE employee SET isAssigned='0' WHERE Employee_ID =(SELECT Member1 from aerospaceteam WHERE Member1=employee.Employee_ID and TeamID="+id+")";
					    int done1=stmt.executeUpdate(sqlChangeIsAssigned1);
					    String sqlChangeIsAssigned2="UPDATE employee SET isAssigned='0' WHERE Employee_ID =(SELECT Member2 from aerospaceteam WHERE Member2=employee.Employee_ID and TeamID="+id+")";
					    int done2=stmt.executeUpdate(sqlChangeIsAssigned2);
					    String sqlChangeIsAssigned3="UPDATE employee SET isAssigned='0' WHERE Employee_ID =(SELECT Member3 from aerospaceteam WHERE Member3=employee.Employee_ID and TeamID="+id+")";
					    int done3=stmt.executeUpdate(sqlChangeIsAssigned3);
					    String getMembers="SELECT * FROM Aerospaceteam WHERE TeamID="+id;
					    ResultSet r=stmt.executeQuery(getMembers);
					    if (r.next())
					    {
					    	mem1=r.getInt("member1");
					    	mem2=r.getInt("member2");
					    	mem3=r.getInt("member3");
					    	
					    }
					    System.out.println(mem1+"   "+mem2+" "+mem3);
					    String del1="Drop Table t"+mem1+"";
					    int del1ok=stmt.executeUpdate(del1);
					    String del2="Drop Table t"+mem2+"";
					    int del2ok=stmt.executeUpdate(del2);
					    String del3="Drop Table t"+mem3+"";
					    int del3ok=stmt.executeUpdate(del3);
					    String sql="DELETE from aerospaceteam WHERE TeamID='"+id+"'";
					    int rs=stmt.executeUpdate(sql);
					    System.out.println(rs);
		              if(rs==1) {
		            	  alert.display("Team "+id+ " Deleted");
		            	  load();
		              }
		              
					}
					catch (Exception ev){
						System.out.println(ev);
						alert.display("Failed to Delete Team");
					}    
			   }
				
				}
				catch(Exception error) {
					alert.display("No Record Selected");
					
				}
	}
	public void backButton(ActionEvent e) throws IOException {
		Parent add = FXMLLoader.load(getClass().getResource("AerospaceManagerDashboard.fxml"));
        Scene hrDashboard=new Scene(add);
        Stage  hrDasboardView=(Stage)((Node)e.getSource()).getScene().getWindow();
        hrDasboardView.setScene(hrDashboard);
	}
	
	public void load() {
		try{
			team.clear();
			int count=0;
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/gndsa","root","");
		    Statement stmt=con.createStatement();
		    String sql="Select * From `AerospaceTeam`";
		    ResultSet rs=stmt.executeQuery(sql);
		  while(rs.next()) {
		    int ID =rs.getInt("TeamID");
		    String mem1=rs.getString("Member1");
		    String mem2=rs.getString("Member2");
		    String mem3=rs.getString("Member3");
		    team.add(new AerospaceTeam (ID,mem1,mem2,mem3));
		    count++;
		    
		    }
		  System.out.println("total Teams= " +count);
		}
		catch (Exception e){
			System.out.println(e);;
		}
		
		
	}
	
}
