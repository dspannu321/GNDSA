package application;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class EmployeeView implements Initializable {
 private Employee selectedEmployee;
 @FXML Label fName;
 @FXML Label lName;
 @FXML Label Dept;
 @FXML Label DOB;
 @FXML Label Position;
 @FXML Label passWord;
 @FXML Label empID;
 @FXML Label initial;
 Stage window;
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		System.out.println(fName.getText().toString());
		
	}
	public void setData(Employee employee)
	{
		
		//initial.setText(lNameI);
		selectedEmployee=employee;
		fName.setText(selectedEmployee.getFirstname());
		lName.setText(selectedEmployee.getLastname());
		String first=fName.getText().toString().substring(0,1).toUpperCase();
		initial.setText(lName.getText().toString()+","+first);
		Dept.setText(selectedEmployee.getDepartment());
		DOB.setText(selectedEmployee.getDob().toString());
		passWord.setText(selectedEmployee.getPassword());
		empID.setText(Integer.toString(selectedEmployee.getId()));
		Position.setText(selectedEmployee.getPosition());
	}
   /* public void setDataVal(int ID,String name, String Cat, String subCat, String type, String planet) {
    	mName.setText(name);
		mCat.setText(Cat);
		mType.setText(type);
		mSubCat.setText(subCat);
		mPlanet.setText(planet);
		mID.setText(Integer.toString(ID));
    	
    	
    }*/
    public void setWindow(Stage window) {
		this.window = window;
	}
    public void closeButtonClicked() {
    	window.close();
    }

    
    public void editEmployee(ActionEvent ev) throws IOException {
   
    		
    		FXMLLoader loader=new FXMLLoader();
    		loader.setLocation(getClass().getResource("EditEmployee.fxml"));
    		Parent table=loader.load();
    		Scene detailedScene=new Scene(table); 
    		EditEmployee controller=loader.getController();
    		controller.setDataVal(empID.getText(),fName.getText(),lName.getText(),Dept.getText(),Position.getText(),passWord.getText(),Date.valueOf(DOB.getText()));
    		Stage stage=new Stage();
    		controller.setWindow(stage);
    		stage.initModality(Modality.APPLICATION_MODAL);
    		Image icon = new Image(getClass().getResourceAsStream("GNDSA.png"));
    	    stage.getIcons().add(icon);
    	    stage.setTitle("Edit INFO");
    		stage.setScene(detailedScene);
    		stage.show();
    		
    }
    public void load(String string) {
    	try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/gndsa","root","");
		    Statement stmt=con.createStatement();
		    String sqlgetEmpID="Select * From employee WHERE Employee_ID="+string;
		    ResultSet resultgetEmp = stmt.executeQuery(sqlgetEmpID);
		    while(resultgetEmp.next())
		    {
		    	fName.setText(resultgetEmp.getString("Employee_Fname"));
				lName.setText(resultgetEmp.getString("Employee_LName"));
				String first=fName.getText().toString().substring(0,1).toUpperCase();
				initial.setText(lName.getText().toString()+","+first);
				Dept.setText(resultgetEmp.getString("Department"));
				DOB.setText(resultgetEmp.getDate("Dob").toString());
				passWord.setText(resultgetEmp.getString("passWord"));
				Position.setText(resultgetEmp.getString("Position"));
				empID.setText(Integer.toString(resultgetEmp.getInt("Employee_ID")));
		    }	
		}
		catch (Exception e) {
			System.out.println(e);
		}
    	
    }

}
