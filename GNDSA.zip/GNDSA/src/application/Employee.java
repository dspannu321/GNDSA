package application;

import java.sql.Date;

import javafx.beans.property.SimpleStringProperty;

public class Employee {

	SimpleStringProperty firstname;
	SimpleStringProperty lastname;
	SimpleStringProperty Department;
	SimpleStringProperty password;
	SimpleStringProperty position;
	Date dob;
	Integer id;
	Employee(int id,String firstName, String lastName, String passWord, String dept, String position,Date dob){
		this.id=new Integer (id);
		this.firstname=new SimpleStringProperty(firstName);
		this.lastname=new SimpleStringProperty(lastName);
		this.password=new SimpleStringProperty(passWord);
		this.Department=new SimpleStringProperty(dept);
		this.position=new SimpleStringProperty(position);
		this.dob=dob;
		
	}

	
	
	public Employee(int id2, String fName, String lName, String dept) {
		this.id=new Integer (id);
		this.firstname=new SimpleStringProperty(fName);
		this.lastname=new SimpleStringProperty(lName);
		this.Department=new SimpleStringProperty(dept);
	}



	public String getFirstname() {
		return firstname.get();
	}



	public void setFirstname(SimpleStringProperty firstname) {
		this.firstname = firstname;
	}



	public Integer getId() {
		return id;
	}



	public void setId(Integer id) {
		this.id = id;
	}



	public String getLastname() {
		return lastname.get();
	}

	public void setLastname(SimpleStringProperty lastname) {
		this.lastname = lastname;
	}

	public String getDepartment() {
		return Department.get();
	}

	public void setDepartment(SimpleStringProperty department) {
		
		Department = department;
	}

	public String getPassword() {
		return password.get();
	}

	public void setPassword(SimpleStringProperty password) {
		this.password = password;
	}



	public String getPosition() {
		return position.get();
	}



	public void setPosition(SimpleStringProperty position) {
		this.position = position;
	}



	public Date getDob() {
		return dob;
	}



	public void setDob(Date dob) {
		this.dob = dob;
	}
	
}

