package application;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ChoiceBox;

public class selectPlanetController implements Initializable {
@FXML ChoiceBox<String> planetChoice;
static String  Planet; 
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		planetChoice.getItems().addAll("Mercury","Venus","Mars","Jupiter");
	}
 public void choiceButtonClicked() {
	 setPlanet(planetChoice.getValue().toString());
 }
public String getPlanet() {
	return Planet;
}
public void setPlanet(String planet) {
	Planet = planet;
}
 
}
