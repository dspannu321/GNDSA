package application;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class missionViewController implements Initializable {
	private Mission searchedMission;
	@FXML Label mName;
	@FXML Label mCat;
	@FXML Label mType;
	@FXML Label mSubCat;
	@FXML Label mPlanet;
	@FXML Label mID;
	Stage window;
	showAlert alert=new showAlert();
	public void setData(Mission mission)
	{
		searchedMission=mission;
		mName.setText(searchedMission.getMissionName());
		mCat.setText(searchedMission.getMissionCategory());
		mType.setText(searchedMission.getMissionType());
		mSubCat.setText(searchedMission.getMissionSubCat());
		mPlanet.setText(searchedMission.getMissionPlanet());
		mID.setText(Integer.toString(searchedMission.getMissionId()));
	}
    public void setDataVal(int ID,String name, String Cat, String subCat, String type, String planet) {
    	mName.setText(name);
		mCat.setText(Cat);
		mType.setText(type);
		mSubCat.setText(subCat);
		mPlanet.setText(planet);
		mID.setText(Integer.toString(ID));
    	
    	
    }

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {


	}
	public void setWindow(Stage window) {
		this.window = window;
	}
    public void closeButtonClicked() {
    	window.close();
    }
    
    public void editMissionBt(ActionEvent ev) throws IOException {
   
    		
    		FXMLLoader loader=new FXMLLoader();
    		loader.setLocation(getClass().getResource("EditMission.fxml"));
    		Parent table=loader.load();
    		Scene detailedScene=new Scene(table); 
    		EditMission controller=loader.getController();
    		controller.setDataVal(mID.getText(),mName.getText(),mCat.getText(),mType.getText(),mSubCat.getText(),mPlanet.getText());
    		Stage stage=new Stage();
    		stage.initModality(Modality.APPLICATION_MODAL);
    		Image icon = new Image(getClass().getResourceAsStream("GNDSA.png"));
    	    stage.getIcons().add(icon);
    	    stage.setTitle("Edit INFO");
    		stage.setScene(detailedScene);
    		stage.show();
    		
    }
	public void load(int missionID) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/gndsa","root","");
		    Statement stmt=con.createStatement();
		    String sqlgetTeamID="Select * From mission WHERE MissionID="+missionID;
		    ResultSet resultgetTeam = stmt.executeQuery(sqlgetTeamID);
		    while(resultgetTeam.next())
		    {
		    	mName.setText(resultgetTeam.getString("MissionName"));
				mCat.setText(resultgetTeam.getString("MissionCat"));
				mType.setText(resultgetTeam.getString("MissionType"));
				mSubCat.setText(resultgetTeam.getString("MissionSubCat"));
				mPlanet.setText(resultgetTeam.getString("MissionPlanet"));
				mID.setText(Integer.toString(missionID));
		    }	
		}
		catch (Exception e) {
			System.out.println(e);
		}
		
		
	}


	
    

}
