package application;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class SearchMissionController  {
@FXML TextField name;
@FXML TextField ID;
@FXML Label outputLabel;
showAlert alert=new showAlert();
public void submitButtonClicked() throws IOException {
	if (name.getText().isEmpty() && ID.getText().isEmpty()) {
		alert.display("Enter Arguements to Search");	
	}
	
	else if (name.getText().isEmpty()==false)
	{
	try{
		 
		Class.forName("com.mysql.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/gndsa","root","");
	    Statement stmt=con.createStatement();
	    String sql="SELECT * FROM mission WHERE missionName ='"+name.getText()+"'";
	    ResultSet result=stmt.executeQuery(sql);
	    
          if(result.next()) {
        	  show(result);
     
          }
          else {
          	
          	alert.display("No Record Found");	
          }
	}
	catch (Exception ev){
		alert.display("No Record Found");	
	}
	}
	else if (ID.getText().isEmpty()==false && name.getText().isEmpty())
	{
	try{
		 
		Class.forName("com.mysql.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/gndsa","root","");
	    Statement stmt=con.createStatement();
	    String sql="SELECT * FROM mission WHERE missionID ='"+ID.getText()+"'";
	    ResultSet result=stmt.executeQuery(sql);
	    
        if(result.next()) {
        	show(result);

          }
        else {
        	
        	alert.display("No Record Found");		
        }
	}
	catch (Exception ev){
		alert.display("No Record Found");	
	}
	}
}
public void clearButtonPushed() {
	name.clear();
	ID.clear();
	outputLabel.setText("");
	
}
public void show(ResultSet result) throws SQLException, IOException {
	 int ID =result.getInt("MissionID");
	    String mName=result.getString("MissionName");
	    String mCat=result.getString("MissionCat");
	    String mSubCat=result.getString("MissionSubCat");
	    String mType=result.getString("MissionType");
	    String mPlanet=result.getString("MissionPlanet");
 	FXMLLoader loader=new FXMLLoader();
		loader.setLocation(getClass().getResource("MissionView.fxml"));
		Parent table=loader.load();
		Scene detailedScene=new Scene(table); 
		missionViewController controller=loader.getController();
		controller.setDataVal(ID,mName,mCat,mSubCat,mType,mPlanet);
		Stage stage=new Stage();
		controller.setWindow(stage);
		stage.initModality(Modality.APPLICATION_MODAL);
		Image icon = new Image(getClass().getResourceAsStream("GNDSA.png"));
	    stage.getIcons().add(icon);
	    stage.setTitle(mName);
		stage.setScene(detailedScene);
		stage.showAndWait();
		stage.close();
	
}

}
