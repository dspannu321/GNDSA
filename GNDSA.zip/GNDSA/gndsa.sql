-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 05, 2018 at 08:53 AM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gndsa`
--

-- --------------------------------------------------------

--
-- Table structure for table `aerospaceteam`
--

CREATE TABLE `aerospaceteam` (
  `TeamID` int(11) NOT NULL,
  `Member1` int(11) NOT NULL,
  `Member2` int(11) NOT NULL,
  `Member3` int(11) NOT NULL,
  `MissionID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `aerospaceteam`
--

INSERT INTO `aerospaceteam` (`TeamID`, `Member1`, `Member2`, `Member3`, `MissionID`) VALUES
(1390, 128, 129, 130, 0);

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `Employee_ID` int(11) NOT NULL,
  `Employee_FName` varchar(15) NOT NULL,
  `Employee_LName` varchar(15) NOT NULL,
  `Department` varchar(15) NOT NULL,
  `passWord` varchar(15) NOT NULL,
  `Dob` date NOT NULL,
  `Position` varchar(30) NOT NULL,
  `isAssigned` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`Employee_ID`, `Employee_FName`, `Employee_LName`, `Department`, `passWord`, `Dob`, `Position`, `isAssigned`) VALUES
(120, 'Pawan', 'Dhaliwal', 'HR', 'S123', '2018-11-29', 'Manager', 0),
(122, 'Dilawar', 'Singh', 'Aerospace', 'S123', '2018-11-05', 'Manager', 0),
(128, 'Simar', 'Singh', 'Aerospace', 'S123', '1996-09-05', 'Engineer', 1),
(129, 'Simrandeep', 'Singh', 'Aerospace', 'S123', '2018-11-11', 'Engineer', 1),
(130, 'Tavleen ', 'Kaur', 'Aerospace', 'S123', '2018-11-08', 'Engineer', 1);

-- --------------------------------------------------------

--
-- Table structure for table `launchvehicle`
--

CREATE TABLE `launchvehicle` (
  `vehicleID` int(11) NOT NULL,
  `vehicleName` varchar(30) NOT NULL,
  `vehicleType` varchar(30) NOT NULL,
  `vehicleMaxMass` int(11) NOT NULL,
  `vehicleStage` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `mission`
--

CREATE TABLE `mission` (
  `MissionID` int(11) NOT NULL,
  `MissionName` varchar(15) NOT NULL,
  `MissionCat` varchar(20) NOT NULL,
  `MissionSubCat` varchar(30) NOT NULL,
  `MissionType` varchar(20) NOT NULL,
  `MissionPlanet` varchar(20) NOT NULL,
  `MissionStatus` varchar(30) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mission`
--

INSERT INTO `mission` (`MissionID`, `MissionName`, `MissionCat`, `MissionSubCat`, `MissionType`, `MissionPlanet`, `MissionStatus`) VALUES
(24760, 'Alpha-XA', 'Planetary', 'NA', 'Fly-By', 'Mars', '0'),
(24761, 'INFO', 'Planetary', 'NA', 'Gravity-Assist', 'Mars', '0');

-- --------------------------------------------------------

--
-- Table structure for table `t128`
--

CREATE TABLE `t128` (
  `SID` int(11) DEFAULT NULL,
  `sendDate` date DEFAULT NULL,
  `Subject` varchar(100) DEFAULT NULL,
  `message` tinytext
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `t128`
--

INSERT INTO `t128` (`SID`, `sendDate`, `Subject`, `message`) VALUES
(70001, '2018-12-03', 'Automatic mail From System.', 'You Have been Assigned to Team 1390 With Group members 129 And 130'),
(130, '2018-12-03', 'Test message', 'Hello this Is Test message.');

-- --------------------------------------------------------

--
-- Table structure for table `t129`
--

CREATE TABLE `t129` (
  `SID` int(11) DEFAULT NULL,
  `sendDate` date DEFAULT NULL,
  `Subject` varchar(100) DEFAULT NULL,
  `message` tinytext
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `t129`
--

INSERT INTO `t129` (`SID`, `sendDate`, `Subject`, `message`) VALUES
(70001, '2018-12-03', 'Automatic mail From System.', 'You Have been Assigned to Team 1390 With Group members 128 And 130');

-- --------------------------------------------------------

--
-- Table structure for table `t130`
--

CREATE TABLE `t130` (
  `SID` int(11) DEFAULT NULL,
  `sendDate` date DEFAULT NULL,
  `Subject` varchar(100) DEFAULT NULL,
  `message` tinytext
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `t130`
--

INSERT INTO `t130` (`SID`, `sendDate`, `Subject`, `message`) VALUES
(70001, '2018-12-03', 'Automatic mail From System.', 'You Have been Assigned to Team 1390 With Group members 128 And 129');

-- --------------------------------------------------------

--
-- Table structure for table `vmass`
--

CREATE TABLE `vmass` (
  `TeamID` int(11) NOT NULL,
  `vehicleID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vmass`
--

INSERT INTO `vmass` (`TeamID`, `vehicleID`) VALUES
(1321, 1000001);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `aerospaceteam`
--
ALTER TABLE `aerospaceteam`
  ADD PRIMARY KEY (`TeamID`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`Employee_ID`);

--
-- Indexes for table `launchvehicle`
--
ALTER TABLE `launchvehicle`
  ADD PRIMARY KEY (`vehicleID`);

--
-- Indexes for table `mission`
--
ALTER TABLE `mission`
  ADD PRIMARY KEY (`MissionID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `aerospaceteam`
--
ALTER TABLE `aerospaceteam`
  MODIFY `TeamID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1391;

--
-- AUTO_INCREMENT for table `employee`
--
ALTER TABLE `employee`
  MODIFY `Employee_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=131;

--
-- AUTO_INCREMENT for table `launchvehicle`
--
ALTER TABLE `launchvehicle`
  MODIFY `vehicleID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mission`
--
ALTER TABLE `mission`
  MODIFY `MissionID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24762;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
